<?php


// Constantes 

require_once ( $conf['appRoot'] . '/php-includes/local/constants.php') ;
require_once ( $conf['appRoot'] . '/php-includes/local/tools.php') ;
require_once ( $conf['appRoot'] . '/php-includes/local/checks.php') ;
require_once ( $conf['appRoot'] . '/php-includes/local/erreurs.php') ;
//~ require_once ( $conf['appRoot'] . '/php-includes/local/tests.php') ;
require_once ( $conf['appRoot'] . '/php-includes/local/rapladb.php') ;
require_once ( $conf['appRoot'] . '/php-includes/local/form.php') ;


require_once($conf['appRoot'] . '/php-includes/fpdi/fpdf.php');
require_once($conf['appRoot'] . '/php-includes/fpdi/fpdi.php');


require_once ($conf['appRoot'] . '/php-includes/objets/utilisateur.php') ;
require_once ($conf['appRoot'] . '/php-includes/objets/pdf.php') ;
require_once ($conf['appRoot'] . '/php-includes/objets/planningPdf.php') ;


define('FPDF_FONTPATH', $conf['appRoot'] . '/php-includes/font/');





//~ require_once( $conf['appRoot'] . '/php-includes/localobj/pdfMaker.php');
//~ require_once( $conf['appRoot'] . '/php-includes/localobj/pdfPlanning.php');

?>