<?php
//Based on HTML2PDF by Cl�ment Lavoillotte

//require('fpdf.php');







class PDF extends FPDF
{
//variables of html parser
var $B;
var $I;
var $U;
var $HREF;
var $fontList;
var $issetfont;
var $issetcolor;

var $titre;
var $sousTitre;
var $colorETT;
var $largCol;
var $titreCol;
var $nbCol;

var $ecran=false;


function PDF($orientation='L',$unit='mm',$format='A4')
{
	//Call parent constructor
	$this->FPDF($orientation,$unit,$format);
	//Initialization
	$this->B=0;
	$this->I=0;
	$this->U=0;
	$this->HREF='';

	$this->tableborder=0;
	$this->tdbegin=false;
	$this->tdwidth=0;
	$this->tdheight=0;
	$this->tdalign="L";
	$this->tdbgcolor=false;

	$this->oldx=0;
	$this->oldy=0;

	$this->fontlist=array("arial");
	$this->issetfont=false;
	$this->issetcolor=false;
	$this->pagePaire=false;
	$this->SetFont('Arial','',20);
}


function confPDF($nb=0,$larg=Array(),$titre=Array(),$color=Array()){
	
	
	$this->largCol=$larg;
	$this->titreCol=$titre;
	$this->colorETT=$color;
	$this->nbCol=$nb;
	$this->date=utf8_decode(strftime(" %A  %d  %B  %G"));
}


//En-t�te
function Header()
{
	if($this->ecran) $this->SetFillColor(0,0,0);
	else $this->SetFillColor(255,255,255);
	//$this->Rect(0,0,800,800,"FD");
	
	//Police Arial gras 15
	
	//D�calage � droite
	//$this->Cell(80);
	//Titre
	//$this->Cell(30,10,'Titre',1,0,'C');
	//Saut de ligne
	$this->Ln(10);
	$this->SetTextColor(0,0,0);
	
	//$this->SetFillColor(255,255,255);
	if($this->titre!=""){
		if($this->ecran) $this->SetTextColor(255,255,255);
		$this->SetFont('Arial','',35);
		$this->SetStyle('B',true);
		$this->cell(297, 10,$this->titre,0,1, 'C', 1);
		$this->SetStyle('B',false);
		$this->Ln(2);
		
		$this->SetFont('Arial','',20);
		$this->SetTextColor(0,0,0);
	}
	if($this->sousTitre!=""){
		if($this->ecran) $this->SetTextColor(255,255,255);
		$this->SetFont('Arial','',25);
		$this->SetStyle('B',true);
		$this->cell(297, 10,$this->sousTitre,0,1, 'C', 1);
		$this->SetStyle('B',false);
		$this->Ln(2);
		
		$this->SetFont('Arial','',20);
		$this->SetTextColor(0,0,0);
	}
	
	//logo (d�form� ou non)
	if($this->ecran){
		$this->Image('logo-sorbonne.png',0,0,25,30);
		$this->Image('logo_iufm.jpg',274,0,23,30);
	}else{
		$this->Image('logo-sorbonne.png',0,0,34.65,30);
		$this->Image('logo_iufm.jpg',267,0,31.23,30);
	}
	
	if($this->nbCol>0){
		$this->SetFillColor($this->colorETT[0], $this->colorETT[1],$this->colorETT[2]);
		for($i=0;$i<$this->nbCol;$i++){
			$this->cell($this->largCol[$i], 15,$this->titreCol[$i],1, 0, 'C', 1);
		}
		$this->Ln();
	}

}


function SetTitre($dd){
	$this->titre=$dd;
}
function SetSousTitre($dd){
	$this->sousTitre=$dd;
}

function SetEcran($val){
	$this->ecran=$val;
}

//////////////////////////////////////
//html parser





function SetStyle($tag,$enable)
{
	//Modify style and select corresponding font
	$this->$tag+=($enable ? 1 : -1);
	$style='';
	foreach(array('B','I','U') as $s)
		if($this->$s>0)
			$style.=$s;
	$this->SetFont('',$style);
}


}//end of class

?>