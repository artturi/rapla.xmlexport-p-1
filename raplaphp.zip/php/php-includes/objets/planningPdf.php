<?php

 


//la classe contenue PDF extends FPDF dans le fichier html_table.php


class PlanningPDF extends fpdf
{

	var  $pdf;

    function PlanningPDF($page,$planning,$hStart=NULL,$hEnd=NULL)
    {
        global $conf;
        
        switch ($page)
        {
            case 'dayRoom':
                $this->dayrooms($planning);	
                break;
            case 'roomDay':
                $this->roomDays($planning);	
                break;
            case 'groupDay' :
                $this->dayGroup($planning);
                break;
			case 'dayGroup' :
                $this->groupDay($planning);
                break;
			case 'dayPerson':
                $this->dayPerson($planning);
                break;
			case 'personDay':
                $this->personDay($planning);
                break;
            case 'globalPdf' :
                $this->planJour($planning,$hStart,$hEnd);
                break;
                
            
        }
     
       
       
    }//fin PlanningEnPDF()
     
    
    
    
    
   function dayrooms($planning)
    {

	$titrePDF='Planning par Jour par Salle';
	  $periode="Du ".$_SESSION['form1']['start']." "."Au ".$_SESSION['form1']['end'];
	 $this->pdf=new PDF();
	 
	   $this->pdf->SetTitre("");
        $this->pdf->AddPage();
       
        $this->pdf->SetTitle($titrePDF);


           
        
        $numhtmlTable=0;
        $modulo=0;
      
	$this->pdf->Ln(50);
	$this->pdf->SetFont('Arial','',25);
        $this->pdf->SetFillColor(255, 255,255);
        $this->pdf->SetStyle('B',true);
        $this->pdf->cell(250, 10,$titrePDF,0,1, 'C', 1);
	$this->pdf->Ln(20);
	$this->pdf->cell(250, 10,$periode,0,1, 'C', 1);
        $this->pdf->SetStyle('B',false);
	$this->pdf->SetFont('Arial','',15);
	$this->pdf->Ln(30);	
	
	

	
	$titre= '".$colonne[6][\'lib\']." ';
	
	
	
	//~ $this->tabPDF($planning,$titre);
	$listCol=Array("salle"=>"Salle(s) :","evt"=>"Evenement :","start"=>"Debut","end"=>"Fin","grp"=>"Groupe : ", "inter"=>"Intervenant(s) :");
	$largcolon=Array(55,70,21,21,35,70);
	$this->tabPDFRess($planning,$titre,$listCol,$largcolon,Array("jour"=>"Jour"),True);	

}


function roomDays($planning)
{
	$titrePDF='Planning  par Salle par Jour';
	  $periode="Du ".$_SESSION['form1']['start']." "."Au ".$_SESSION['form1']['end'];
	 $this->pdf=new PDF();
	 
	   $this->pdf->SetTitre("");
        $this->pdf->AddPage();
       
        $this->pdf->SetTitle($titrePDF);


           
        
        $numhtmlTable=0;
        $modulo=0;
      
	$this->pdf->Ln(50);
	$this->pdf->SetFont('Arial','',25);
        $this->pdf->SetFillColor(255, 255,255);
        $this->pdf->SetStyle('B',true);
        $this->pdf->cell(250, 10,$titrePDF,0,1, 'C', 1);
	$this->pdf->Ln(20);
	$this->pdf->cell(250, 10,$periode,0,1, 'C', 1);
        $this->pdf->SetStyle('B',false);
	$this->pdf->SetFont('Arial','',15);
	$this->pdf->Ln(30);	
	
	

	
	//$titre= '".utf8_decode(strftime(" %A  %d  %B  %G",strtotime($curDate)))."';
	

	$titre= ' Salle : ".$colonne[6][\'lib\']." ';
	//print_r($planning);
	$listCol=Array("jour"=>"Jour","start"=>"Debut","end"=>"Fin","grp"=>"Groupe : ", "inter"=>"Intervenant(s) :","evt"=>"Evenement :");
	$largcolon=Array(35,21,21,65,65,65);
	$this->tabPDFRess($planning,$titre,$listCol,$largcolon,Array("salle"=>"Salle(s) :"),True);	
	// $this->pdf->Output();

}

function dayGroup($planning)
    {
	$titrePDF='Planning par Jour par Groupe';
	  $periode="Du ".$_SESSION['form2']['start']." "."Au ".$_SESSION['form2']['end'];
	 $this->pdf=new PDF();
	 
	   $this->pdf->SetTitre("");
        $this->pdf->AddPage();
       
        $this->pdf->SetTitle($titrePDF);


           
        
        $numhtmlTable=0;
        $modulo=0;
      
	$this->pdf->Ln(50);
	$this->pdf->SetFont('Arial','',25);
        $this->pdf->SetFillColor(255, 255,255);
        $this->pdf->SetStyle('B',true);
        $this->pdf->cell(250, 10,$titrePDF,0,1, 'C', 1);
	$this->pdf->Ln(20);
	$this->pdf->cell(250, 10,$periode,0,1, 'C', 1);
        $this->pdf->SetStyle('B',false);
	$this->pdf->SetFont('Arial','',15);
	$this->pdf->Ln(30);	
	
	

	
	$titre= '".$colonne[6][\'lib\']." ';
	
	
	
	//~ $this->tabPDF($planning,$titre);	
	$listCol=Array("grp"=>"Groupe : ","evt"=>"Evenement :","start"=>"Debut :","end"=>"Fin :","inter"=>"Intervenant(s) :","salle"=>"Salle(s) :");
	$largcolon=Array(40,68,25,25,70,53);
	$this->tabPDFRess($planning,$titre,$listCol,$largcolon,Array("jour"=>"Jour :"),True);	

	// $this->pdf->Output();
   }
   
function groupDay($planning){
	$titrePDF='Planning  par Groupe par Jour';
	  $periode="Du ".$_SESSION['form2']['start']." "."Au ".$_SESSION['form2']['end'];
	 $this->pdf=new PDF();
	 
	   $this->pdf->SetTitre("");
        $this->pdf->AddPage();
       
        $this->pdf->SetTitle($titrePDF);


           
        
        $numhtmlTable=0;
        $modulo=0;
      
	$this->pdf->Ln(50);
	$this->pdf->SetFont('Arial','',25);
        $this->pdf->SetFillColor(255, 255,255);
        $this->pdf->SetStyle('B',true);
        $this->pdf->cell(250, 10,$titrePDF,0,1, 'C', 1);
	$this->pdf->Ln(20);
	$this->pdf->cell(250, 10,$periode,0,1, 'C', 1);
        $this->pdf->SetStyle('B',false);
	$this->pdf->SetFont('Arial','',15);
	$this->pdf->Ln(30);	
	
	

	
	//$titre= '".utf8_decode(strftime(" %A  %d  %B  %G",strtotime($curDate)))."';
	
	$titre= ' Groupe : ".$colonne[6][\'lib\']." ';
	//print_r($planning);
	$listCol=Array("jour"=>"Jour :","start"=>"Debut :","end"=>"Fin :","inter"=>"Intervenant(s) :","salle"=>"Salle(s) :","evt"=>"Evenement :");
	$largcolon=Array(45,30,30,65,40,55);
	$this->tabPDFRess($planning,$titre,$listCol,$largcolon,Array("grp"=>"Groupe : "),True);	
	// $this->pdf->Output();

}


function dayPerson($planning)
    {
	$titrePDF='Planning par Jour par Intervenant';
	  $periode="Du ".$_SESSION['form3']['start']." "."Au ".$_SESSION['form3']['end'];
	 $this->pdf=new PDF();
	 
	   $this->pdf->SetTitre("");
        $this->pdf->AddPage();
       
        $this->pdf->SetTitle($titrePDF);


           
        
        $numhtmlTable=0;
        $modulo=0;
      
	$this->pdf->Ln(50);
	$this->pdf->SetFont('Arial','',25);
        $this->pdf->SetFillColor(255, 255,255);
        $this->pdf->SetStyle('B',true);
        $this->pdf->cell(250, 10,$titrePDF,0,1, 'C', 1);
	$this->pdf->Ln(20);
	$this->pdf->cell(250, 10,$periode,0,1, 'C', 1);
        $this->pdf->SetStyle('B',false);
	$this->pdf->SetFont('Arial','',15);
	$this->pdf->Ln(30);	
	
	

	
	$titre= '".$colonne[6][\'lib\']." ';
	
	
	
	//~ $this->tabPDF($planning,$titre);	
	$listCol=Array("inter"=>"Intervenant(s) :","evt"=>"Evenement :","start"=>"Debut : ","end"=>"Fin : ","grp"=>"Groupe : ","salle"=>"Salle(s) :");
	$largcolon=Array(65,55,30,30,55,40);
	$this->tabPDFRess($planning,$titre,$listCol,$largcolon,Array("jour"=>"Jour"),True);	
	

	// $this->pdf->Output();
   }

function personDay($planning){
	$titrePDF='Planning  par Intervenant par Jour';
	  $periode="Du ".$_SESSION['form3']['start']." "."Au ".$_SESSION['form3']['end'];
	 $this->pdf=new PDF();
	 
	   $this->pdf->SetTitre("");
        $this->pdf->AddPage();
       
        $this->pdf->SetTitle($titrePDF);


           
        
        $numhtmlTable=0;
        $modulo=0;
      
	$this->pdf->Ln(50);
	$this->pdf->SetFont('Arial','',25);
        $this->pdf->SetFillColor(255, 255,255);
        $this->pdf->SetStyle('B',true);
        $this->pdf->cell(250, 10,$titrePDF,0,1, 'C', 1);
	$this->pdf->Ln(20);
	$this->pdf->cell(250, 10,$periode,0,1, 'C', 1);
        $this->pdf->SetStyle('B',false);
	$this->pdf->SetFont('Arial','',15);
	$this->pdf->Ln(30);	
	
	

	
	//$titre= '".utf8_decode(strftime(" %A  %d  %B  %G",strtotime($curDate)))."';
	
	$titre= ' Intervenant : ".$colonne[6][\'lib\']." ';
	//print_r($planning);
	$listCol=Array("jour"=>"Jour","start"=>"Debut :","end"=>"Fin :","grp"=>"Groupe : ","salle"=>"Salle(s) :","evt"=>"Evenement :");
	$largcolon=Array(35,30,30,55,40,65);
	$this->tabPDFRess($planning,$titre,$listCol,$largcolon,Array("inter"=>"Intervenant(s) :"),True);	
	// $this->pdf->Output();

}

function planJour($planning,$hstart,$hend)
    {
    

        global $debug;
	global $resource; //ds fichier constants.php fait la corespondance entre id (ex:'resource9') et le nom 
	
	$group=$_GET['group'];
	
	$groupName="";
	if(is_array($group)){
		foreach($group as $Name){
			if($debug)echo"<br>Resource = $Name";
			$groupName.=$resource[$Name]." ";
		}
	}else{
		$groupName=$resource[$group];
	}
	if($debug)echo "<br>get : $group , val group :$groupName <br>";
        
        //la classe contenue PDF extends FPDF dans le fichier html_table.php
        // donc on peut faire appel aux m�thodes   $this->pdf->SetFont et $this->pdf->AddPage() et toutes les autres m�thodes de la classe  FPDF
        //gr�ce � l'h�ritage de FPDF par la classe PDF extends FPDF dans le fichier html_table.php
      
       
	$titre= '  ".$colonne[6][\'lib\']." '; 
	//~ $titre= $groupName.' : ".$colonne[6][\'lib\']." '; 
	$sousTitre = 'Entre  '.$hstart.'H00  et '.$hend.'H00 ';
		
	$this->pdf=new PDF();
	$this->pdf->SetEcran('true');

	$listCol=Array("grp"=>"Groupe : ","evt"=>"Evenement :","start"=>"Debut : ","end"=>"Fin : ","inter"=>"Intervenant(s) :","salle"=>"Salle(s) :");
	$largcolon=Array(40,68,25,25,70,53);
	//$largcolon=Array(65,55,30,30,55,40);
	$this->tabPDFRess($planning,$titre,$listCol,$largcolon,Array("jour"=>"Jour"),True,$sousTitre);	
        
	//~ $titre=$groupName.' :".utf8_decode(strftime(" %A  %d  %B  %G",strtotime($curDate)))."';
        
	
	
	//~ $this->tabPDF($planning,$titre);
}


function planJourAdd($planning,$hstart,$hend)
    {
    

        global $debug;
	global $resource; //ds fichier inc.php fait la corespondance entre id 'resource9' et le nom 
	
	$group=$_GET['group'];
	
	$groupName="";
	if(is_array($group)){
		foreach($group as $Name){
			if($debug)echo"<br>Resource = $Name";
			$groupName.=$resource[$Name]." ";
		}
	}else{
		$groupName=$resource[$group];
	}
	if($debug)echo "<br>get : $group , val group :$groupName <br>";
        
        //la classe contenue PDF extends FPDF dans le fichier html_table.php
        // donc on peut faire appel aux m�thodes   $this->pdf->SetFont et $this->pdf->AddPage() et toutes les autres m�thodes de la classe  FPDF
        //gr�ce � l'h�ritage de FPDF par la classe PDF extends FPDF dans le fichier html_table.php
      
       
        
	//~ $titre=$groupName.' :".utf8_decode(strftime(" %A  %d  %B  %G",strtotime($curDate)))." ';
	$titre=' ".utf8_decode(strftime(" %A  %d  %B  %G",strtotime($curDate)))." ';
	$sousTitre = 'Entre  '.$hstart.'H00 et '.$hend.'H00 ';
	//$this->pdf=new PDF();
	
	$this->tabPDF($planning,$titre,$sousTitre);
}


//
function tabPDF($planning,$titre,$sousTitre=""){

	global $debug,$resource;
	
	
	if($debug=true)echo "<br> tabPDF : <br>";
	//largeur des colonnes du tableau
  		
	$largcolon=Array(40,68,25,25,70,53);
	$titreCol=Array("Groupe:","Evenement:","Debut:","Fin:","Intervenant(s)","Salle(s):");
	$colorETT=Array(255,165,0);
	$titrePage="";
	
	$modulo=0;
	 
	
	if(count($planning)>0){
	
		$this->pdf->confPDF(6,$largcolon,$titreCol,$colorETT);
		
		$this->pdf->SetAutoPageBreak(true);
			
		foreach ($planning as $curDate => $grpEvents)
		{	
			
			if($debug)echo "$titre<br>";
			eval ( "\$titrePage =\"$titre\";" );
			$titrePage=utf8_decode($titrePage);
			if($debug)echo "$titrePage<br>";
			
			//$nblines=8;
			$this->pdf->SetTitre($titrePage);
			
			
			
			$this->pdf->AddPage();
			
			
			
			foreach ($grpEvents as $event)
			{
				
			 
				$modulo+=1;
				
				
				 if(($modulo%2)==0)
				{	
					$r=224;
					$v=235;
					$b=255;

				}
		
				if(($modulo%2)>=1)
				{
					$r=255;
					$v =192;
					$b=203;
				
				}
			    
				
				$this->pdf->SetFillColor($r,$v,$b);
			       
			
			
				
				/*
				*R�cup�ration des information � afficher
				*/
				
				
				$listGroups=$this->getListGroups($event);
				$myevent=trim(utf8_decode($event['name']));
				if(utf8_decode($event['name']=="")){$myevent="";}
				$start=$event['start'];
				$end=$event['end'];
				
				$listIntervenants=$this->listIntervenants($event);  
				$salle=$this->getSalle($event);
				
				
				/*
				* Pr�paration de la hauteur de chaque ligne
				*/
				
				/*Initialisation des variables */
				//hauteur de la ligne en cours (peu �tre modifi� si donn�e su r plusieurs lignes
				$hautLign=12;
				
				
				
				//nombre de ligne que n�cessitera la case, pour calculer la hauteur des autre case de la ligne
				$divGrp=1;
				$divStart=1;
				$divEnd=1;
				$divEvts=1;
				$divInter=1;
				$divSalle=1;
				
				//le nombre de ligne maximal
				$divMax=1;
				
				
				/*calcul de la hauteur n�c�ssaire pour chaque case */
				$divGrp=$this->calculNbLigne($listGroups,$largcolon[0]);
				
				if ($divGrp>$divMax) $divMax=$divGrp;
				
				
				//r�cup�re le nombre ligne de la case
				$divEvts=$this->calculNbLigne($myevent,$largcolon[1]);
				
				if ($divEvts>$divMax) $divMax=$divEvts;
				
			
				$divStart=$this->calculNbLigne($start,$largcolon[2]);
				
				
				if ($divStart>$divMax) $divMax=$divStart;
					
					
				//r�cup�re le nombre ligne de la case
				$divEnd=$this->calculNbLigne($end,$largcolon[3]);
				
				if ($divEnd>$divMax) $divMax=$divEnd;
				
				
		
				//r�cup�re le nombre ligne de la case
				$divInter=$this->calculNbLigne($listIntervenants,$largcolon[4]);
				
				if ($divInter>$divMax) $divMax=$divInter;
			
		
				//r�cup�re le nombre ligne de la case
				$divSalle=$this->calculNbLigne($salle,$largcolon[5]);

				if ($divSalle>$divMax) $divMax=$divSalle;
			
				//Celui qui a le plus de ligne d�fini la hauteur de la ligne
				$hautLign=$hautLign*$divMax;
				
				
				
				/*
				* Affichage
				*/
		
				//petite v�rification si un changement de page est n�cessaire (surtout si la premi�re cellule fais plus d'une ligne
				$y=$this->pdf->GetY();
				if($debug) echo "<br>Dans pdf y: $y";
				if($y+$hautLign>210){
					$this->pdf->addPage();
				}
				
				$x=$this->pdf->GetX();
				//Affichage : Cr�ation des cellules du pdf 
				$this->pdf->MultiCell($largcolon[0],$hautLign/$divGrp,$listGroups,1,'C',1);
				$y=$this->pdf->GetY();
				$y=$y-$hautLign;
				
				$this->pdf->SetY($y);
				$x=$x+$largcolon[0];
				$this->pdf->SetX($x);

				   $this->pdf->MultiCell($largcolon[1], $hautLign/$divEvts, $myevent,1,  'C', 1);
				$this->pdf->SetY($y);
				$x=$x+$largcolon[1];
				$this->pdf->SetX($x);
				
				
				$this->pdf->MultiCell($largcolon[2], $hautLign/$divStart,$start,1,  'C', 1);
				$this->pdf->SetY($y);
				$x=$x+$largcolon[2];
				$this->pdf->SetX($x);
				
				
				
				$this->pdf->MultiCell($largcolon[3], $hautLign/$divEnd, $end,1,  'C', 1);
				$this->pdf->SetY($y);
				$x=$x+$largcolon[3];
				$this->pdf->SetX($x);
				
			     
				$this->pdf->MultiCell($largcolon[4], $hautLign/$divInter, $listIntervenants ,1,  'C', 1);
				$this->pdf->SetY($y);
				$x=$x+$largcolon[4];
				$this->pdf->SetX($x);
				
				$this->pdf->MultiCell($largcolon[5], $hautLign/$divSalle,$salle,1,  'C', 1);
				$this->pdf->SetY($y);
				$x=$x+$largcolon[5];
				$this->pdf->SetX($x);
				$this->pdf->MultiCell(0,$hautLign,"");
		      
				
			}    
		    
		    
		}
		if(!$debug){
			//~ header('Content-Type: application/pdf');
			//~ $this->pdf->Output();
		}
		return 1;
	}else{
		//$this->pdf->AddPage();
			
		//$this->pdf->Ln(100);
		//$this->pdf->Cell(0,0,"Aucunes informations pour $groupName",0,0,'C',0);
		Echo "Pas d'informations pour le groupe  $groupName"; 
		return 0;
	}
	
    }
    
    

/* fonction semblabe a TabPDF mais qui sera utilis� pour afficher les donn� rang� par type de Ressource (et non par date)
D'ou l'apparition des jour dans le tableau.
Param :
$planning : tableau contenant toutes les infos � afficher
$titre : formule du titre qui sera evaluer au d�but de chaque page
$listCol : liste des colonnes � afficher en plus du joure et des heures,  en effet suivant la ressource principal en titre  les colonnes sont diff�rentes 
$nomEntier : bool�en si � True affiche le nom des ressources de facon enti�re et False les affiche de facon abr�ger pour certain  (principalement pour les groupe les PE il est possible d'afficher juste la lettre des groupes )
*/
function tabPDFRess($planning,$titre,$listCol,$largcolon,$titreCol,$nomEntier,$sousTitre=""){

	global $debug,$resource;
	
	if($debug)echo "<br> tabPDFRess : <br>";
	
	//v�rifie qu'il y a bien des informations � afficher 
	if(count($planning)>0){
	
		$tailleTab=sizeof($listCol);
		
		if($debug){
			echo "<br>listCol :";
			print_r($listCol);
		}
		
		
		
		$titreTab=Array(); //titre des colonnes du tableau
		
		
		
		//parcour le tableau  listCol pour connaitre pour d�finir la taille des colonne et surtout le titre de chaque colonne
		foreach ($listCol as $col){
			array_push($titreTab,$col);
		}
		
		
		$colorETT=Array(255,165,0); //couleur du bandeau de titre 
		$titrePage="";
		
		if($debug){
			echo "<br>largcolon :";
			print_r($largcolon);
			echo "<br>titreTab :";
			print_r($titreTab);
		}
		
		$modulo=0;
	 
	 
	
	
	
	
		//pr�paration de la pemi�re ligne du tableau de chaque page
		$this->pdf->confPDF($tailleTab,$largcolon,$titreTab,$colorETT);
		
		//permet un saut de page automatique
		$this->pdf->SetAutoPageBreak(true);
			
		$listCol+=$titreCol;	
		foreach ($planning as $curRes => $grpEvents)
		{	
		
			$newPage=True;
			
			
			
			
			foreach ($grpEvents as $event)
			{
				
				
					/*
				*R�cup�ration des information � afficher
				*/
				
			
				$i=0;
				
				if($debug){ echo "<br> listColTout : ";print_r($listCol);}
				
				foreach ( $listCol as $keyCol => $col){
					switch($keyCol) {
						case 'jour':
							$colonne[$i]['lib']=strftime  ("%A %e %B %Y",$event['start']);
							$colonne[$i]['div']=1;
						break;
						case 'start' :
							$colonne[$i]['lib']=strftime  ("%Hh%M",$event['start']);
							$colonne[$i]['div']=1;
						break;
						case 'end':
							$colonne[$i]['lib']=strftime  ("%Hh%M",$event['end']);
							$colonne[$i]['div']=1;
						break;
						case 'grp':
							if($nomEntier)
								$colonne[$i]['lib']=$this->getListGroupsEntier($event);
							else
								$colonne[$i]['lib']=$this->getListGroups($event);
							$colonne[$i]['div']=1;
							break;
						case 'evt':
							$colonne[$i]['lib']=trim(utf8_decode($event['name']));
							if(utf8_decode($event['name']=="")){$colonne[$i]['lib']="";}
							$colonne[$i]['div']=1;
							break;
						case 'salle':
							$colonne[$i]['lib']=$this->getSalle($event);
							$colonne[$i]['div']=1;
							
							break;
						case 'inter':
							$colonne[$i]['lib']=$this->listIntervenants($event);  
							$colonne[$i]['div']=1;
							break;
						
					}
					$i++;
				}
				
				
			
			
						
				
				if($newPage){
					
					if($debug)echo "titre : $titre<br>";
					eval ( "\$titrePage =\"$titre\";" );
					$titrePage=utf8_decode($titrePage);
					if($debug)echo "$titrePage<br>";
					
					//$nblines=8;
					$this->pdf->SetTitre($titrePage);
					$this->pdf->SetSousTitre($sousTitre);
					
					
					
					$this->pdf->AddPage();
					$newPage=False;
				}
							 
				$modulo+=1;
				
				
				 if(($modulo%2)==0)
				{	
					$r=224;
					$v=235;
					$b=255;

				}
		
				if(($modulo%2)>=1)
				{
					$r=255;
					$v =192;
					$b=203;
				
				}
			    
				
				$this->pdf->SetFillColor($r,$v,$b);
			       
			
			
			
				
				
				/*
				* Pr�paration de la hauteur de chaque ligne
				*/
				
				/*Initialisation des variables */
				//hauteur de la ligne en cours (peu �tre modifi� si donn�e su r plusieurs lignes
				$hautLign=12;
				
				
			
				//le nombre de ligne maximal
				$divMax=1;
				
				
				/*calcul de la hauteur n�c�ssaire pour chaque case */
				
				
				
		
				
				for($i=0;$i<$tailleTab;$i++){
					$colonne[$i]['div']=$this->calculNbLigne($colonne[$i]['lib'],$largcolon[$i]);
					if ($colonne[$i]['div']>$divMax) $divMax=$colonne[$i]['div'];	
				}
				
				
			
				//Celui qui a le plus de ligne d�fini la hauteur de la ligne
				$hautLign=$hautLign*$divMax;
				
				
				
				/*
				* Affichage
				*/
		
				//petite v�rification si un changement de page est n�cessaire (surtout si la premi�re cellule fais plus d'une ligne
				$y=$this->pdf->GetY();
				if($debug) echo "<br>Dans pdf y: $y";
				if($y+$hautLign>210){
					$this->pdf->addPage();
				}
				
				
				$x=$this->pdf->GetX();
				//Affichage : Cr�ation des cellules du pdf 
				if($debug) echo "<br>lib : ".$colonne[0]['lib']." | <br>"; 
				//~ $colonne[0]['lib']=str_replace("\n","",$colonne[0]['lib']);
				$this->pdf->MultiCell($largcolon[0],$hautLign/$colonne[0]['div'],$colonne[0]['lib'],1,'C',1);
				$y=$this->pdf->GetY();
				$y=$y-$hautLign;
				
				$this->pdf->SetY($y);
				$x=$x+$largcolon[0];
				$this->pdf->SetX($x);

		
				for($i=1;$i<$tailleTab;$i++){
					$this->pdf->MultiCell($largcolon[$i], $hautLign/$colonne[$i]['div'],$colonne[$i]['lib'],1,  'C', 1);
					$this->pdf->SetY($y);
					$x=$x+$largcolon[$i];
					$this->pdf->SetX($x);
				}
				
				$this->pdf->MultiCell(0,$hautLign,"");
				
				
		      
				
			}    
		    
		    
		}
		if(!$debug){
			//~ header('Content-Type: application/pdf');
			//~ $this->pdf->Output();
		}
		return 1;
	}else{
		//$this->pdf->AddPage();
			
		//$this->pdf->Ln(100);
		//$this->pdf->Cell(0,0,"Aucunes informations pour $groupName",0,0,'C',0);
		//echo "Pas d'informations pour le groupe  $groupName"; 
		return 0;
	}
	
    }
    
	

function getListGroupsEntier($event)
    {
	global $debug;
	
        $listGroups="";
        foreach ($event['groups'] as $group)
        {

           
            $nomgroupe=$group['name'];
	   
	   
	    
	    
           
            $listGroups.= $nomgroupe."\n";

      
        } //fin foreach ($event['groups'] as $group) 
        
	
        return trim($listGroups);
    }
    

   function getListGroups($event)
    {
	global $debug;
	
        $listGroups="";
        foreach ($event['groups'] as $group)
        {

           
            $nomgroupe=$group['name'];
	   
	    /*if(eregi("^pe2 ",$nomgroupe) || eregi("^pe1 ",$nomgroupe) ){
		 $tabGroupe=explode(" ",$nomgroupe,2);
		 if($debug) {
			echo "<br> tableau des chaines du groupe :";
			print_r($tabGroupe);
			
		}
		if(count($tabGroupe)>1)
		{ 
			$nomgroupe=$tabGroupe[1];
		}
	    }*/
	    
           
            $listGroups.= $nomgroupe."\n";

      
        } //fin foreach ($event['groups'] as $group) 
        
	
        return trim($listGroups);
    }
    
    function getSalle($event){
        $salle="";
        foreach ($event['rooms'] as $room)
        {
        
            $salle.= utf8_decode($room['name'])."\n";
               
        }
        return trim($salle);
    }
    
    
    function listIntervenants($event){
    
        $listIntervenants ="";
        foreach ($event['intervenants'] as $intervenant)
        {
	    if(isset($intervenant['intitule'])) $intitule=$intervenant['intitule'];
	    else $intitule="";
            $listIntervenants .=$intitule." ".$intervenant['surname']."\n";
              /*     
            foreach ($intervenant as $myintervenant=>$nomintervenant)
            {
              
                if($myintervenant=='surname')
                {
    
                    if(utf8_decode($nomintervenant)==null){$nomintervenant="";    }
                  
                    $listIntervenants .= "  ".utf8_decode($nomintervenant);
                    
                }
		

            }*/
        }
        if ($listIntervenants=="") $listIntervenants="";
        return trim($listIntervenants);
    }



/*
fonctions qui avec le texte � afficher et la largeur de la colonne calcul sa hauteur

*/  


   function calculNbLigne($txt,$largTxt)
    {
	global $debug;
	$tab=split("\n", $txt);
	$i=0;
	foreach ( $tab as $sousTxt){
		$i=$i+$this->getDiv($sousTxt,$largTxt);
		
	}
	if($debug)echo " i : $i ++ ";
	return $i;
}

    function getDiv($txt,$largTxt)
    {
	global $debug;
	$largTxt=$largTxt-2;
	//r�cup�re la taille du texte dans le pdf
	$larg=$this->pdf->GetStringWidth($txt);
	$div=1;
	if($larg>$largTxt){
		//echo  "<br> taille superieur";
		$tabTxt=explode(" ",$txt);
		$div=$this->trouveNbLigne(0,$tabTxt,$largTxt);
	
	} 
	//r�cup�re le nombre ligne de la case
	//$div=ceil( ($larg/$largTxt) );
	if($debug) echo "<br> $txt : $larg | $div ";
	return $div;
     }	
     
     function trouveNbLigne($i,$tabTxt,$largTxt){
	global $debug;
	$div=1;
	
	if(count($tabTxt)>$i){
		$txtTest=$tabTxt[$i];
		$tailleTxt=$this->pdf->GetStringWidth($txtTest);
		
		if($tailleTxt>$largTxt)   //le mots est plusgrd donc tronqu�
		{
			if($debug) echo "<br> +grd $tailleTxt ";
			
			
			//cette boucle permet de connaitre les lettres restante pour la ligne suivante 
			$j=0;
			do{
			  $j=$j-1;
			  $nvMsg=substr($tabTxt[$i],0,$j);
			}while($this->pdf->GetStringWidth($nvMsg)>$largTxt);
			
			
			//concat�ne le reste du ernier mots avec le suivant 
			if(isset($tabTxt[$i+1])){
				$nvMsg=substr($tabTxt[$i],$j)." ".$tabTxt[$i+1];
			}else{
				$nvMsg=substr($tabTxt[$i],$j);
			}
			if($debug) echo "<br> nvmesg : $nvMsg";
			$tailleTmp=$this->pdf->GetStringWidth($nvMsg);
			
			/*
			si les reste plus le suivant mots sont trop grand pour tennir dans une ligne alors le reste sera seul sur cette ligne (donc une ligne de plus) 
			il suffit de v�rifier pour les mots suivant (sans le reste)
			Sinon le reste et le mots suivant seront sur la m�me ligne, je les regroupe donc pour connaitre si d'autres mots peuvent �tre aussi sur la m�me ligne
			*/
			if($tailleTmp>$largTxt){ 
				$div++;
				$i++;
				$div+=$this->trouveNbLigne($i,$tabTxt,$largTxt);
			}else{
				$i++;
				$tabTxt[$i]=$nvMsg;
				$div+=$this->trouveNbLigne($i,$tabTxt,$largTxt);
			}
		}else{
			if($debug) echo "<br> -grd $tailleTxt";
			$i++;
			$div+=$this->trouveNbChp($i,$tabTxt,$largTxt,$txtTest);
		}
	}
	if($debug) echo "<br> trouve $i $div ";
	
	return $div;
	
     }
	
      function trouveNbChp($i,$tabTxt,$largTxt,$txtTest)
      {
	global $debug;
	 $div=0;
	 if($debug) echo "<br> chp $i $div ";
	 if(count($tabTxt)>$i){
		 $txtTest.=" $tabTxt[$i]";
		 $tailleTxt=$this->pdf->GetStringWidth($txtTest);
		 if($tailleTxt>$largTxt){
			if($debug) echo "<br>  + grd T $tailleTxt ";
			$div=$this->trouveNbLigne($i,$tabTxt,$largTxt);
		 }else{
			if($debug) echo "<br> -grd T $tailleTxt";
			$i++;
			$div=$this->trouveNbChp($i,$tabTxt,$largTxt,$txtTest);
		 }
	  }		
	  return $div;
	 
      }


} //fin de la classe
   




?>
