<?php

class utilisateur
{


	private $uid;
	public $lecture=FALSE;
	public $manag=FALSE;
	public $interv=FALSE;


    private $ldapconn;
	
    
	function  __construct($uid) 
	{
		$this->uid=$uid;
        $this->connLdap();
		$this->setDroit();
	}

	function setDroit()
	{
		global $conf;
		
		$this->verifLecture();
		
		if (in_array($this->uid,$conf ["managers"]) )
		{
          
			$this->manag=TRUE;
		}
		else
		{
			$this->manag=FALSE;
		}
	
	
	}
	
    

    
    private function  verifLecture()
    {
        //$uid=utf8_encode($uid);
		$dn="ou=groups,dc=paris,dc=iufm,dc=fr";
		
 
		$filtre='(&(objectclass=supannGroupe)(cn=enseignants_personnels_IUFM)(uniquemember=*'. $this->uid.'*))';
		

		$restriction = array("cn");
     
		$sr=ldap_search($this->ldapconn, $dn, $filtre, $restriction);
    
		$info = ldap_get_entries($this->ldapconn, $sr);
      
	    if ( isset($info[0]['cn'][0] ) == true  )
        {
            $this->lecture=TRUE;
            $this->interv=TRUE;
            
		}else{
			$this->lecture=FALSE;
		}
		
    }
    
    
	
	private function connLdap()
	{	
		global $conf;
		
		$ldapbind = false;

		//Connexion au serveur LDAP
		$ldapconn = ldap_connect ($conf ["serveurLDAP1"]);



		if ($ldapconn) {
		   //Connexion au serveur LDAP
		   //$ldapbind = ldap_bind($ldapconn, 'uid=' . $_SERVER['PHP_AUTH_USER'] . ',ou=people,dc=paris,dc=iufm,dc=fr', $_SERVER['PHP_AUTH_PW']);
			$ldapbind = ldap_bind($ldapconn, $conf["dnUser"], $conf["dnPass"]);
		  
		}



		// Identification
		if (!$ldapconn || !$ldapbind) {
			//Connexion au serveur LDAP
			$ldapconn = ldap_connect ($conf ["serveurLDAP2"]) 
			   or die ("Impossible de se connecter au serveur LDAP.");
			   
			if ($ldapconn) {
				//Connexion au serveur LDAP
				//$ldapbind = ldap_bind($ldapconn, 'uid=' . $_SERVER['PHP_AUTH_USER'] . ',ou=people,dc=paris,dc=iufm,dc=fr', $_SERVER['PHP_AUTH_PW']);
				$ldapbind = ldap_bind($ldapconn, $conf["dnUser"], $conf["dnPass"]);
				
				if(!$ldapbind){
					die("Connexion LDAP �chou�e");
				}
			}
		}
		
		$this->ldapconn=$ldapconn;

	
	
	}
	
	
	

}

?>