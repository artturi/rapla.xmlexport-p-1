<?php

class erreurs {

	function msgErreurs($err)
	{        
        $errorArray = explode('-', $err);
        $ret = array();
        foreach ($errorArray as $error)
        {
            switch ($error)
            {
                /*
                 * Erreurs relatives � l'�tat-civil
                 */                
                case ECHEC_DE_CONNEXION : $ret[] = 'Echec de connexion';
                    break;
                case DOIT_PASSER_PAR_SON_DOSSIER: $ret[] = 'Vous avez d�j� enregistr� un dossier. Merci d\'utiliser ce dossier existant.';
                    break;
                case SESSION_EXPIREE: $ret[] = 'Votre session a expir�.';
                    break;
            }
        }
        return $ret;
	}
}


?>