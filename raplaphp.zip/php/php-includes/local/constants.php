<?php

define ("OK", 0);

$resource['defaultResource']="SALLES_BAT";
$resource['resource1']="SALLES_MOL";
$resource['resource5']="PE1";
$resource['resource7']="PE2";
$resource['resource9']="PLC1";
$resource['resource10']="PLC2";
$resource['resource18']="CPE1";
$resource['resource20']="CPE2";
$resource['resource8']="Form. Continue";
$resource['resource22']="Etudiant P4";
$resource['resource17']="Stag. Situation";
$resource['resource23']="T1";
$resource['resource11']="COLLEGES";
$resource['resource12']="FGC";
$resource['resource13']="GROUPE_ASH";
$resource['resource14']="DIVERS";
$resource['resource21']="DIVERS_INVISIBLE";
$resource['person1']="INTERVENANTS";

define ("SALLES_BAT", "resource0");
define ("SALLES_MOL", "resource1");
define ("GROUPE_PE1", "resource5");
define ("GROUPE_PE2", "resource7");
define ("GROUPE_PLC1", "resource9");
define ("GROUPE_PLC2", "resource10");
define ("GROUPE_CPE1", "resource18");
define ("GROUPE_CPE2", "resource20");
define ("GROUPE_FC", "resource8");
define ("GROUPE_ETU_P4", "resource22");
define ("GROUPE_SITUA","resource17");
define ("GROUPE_T1", "resource23");
define ("COLLEGES", "resource11");
define ("GROUPE_FGC", "resource12");
define ("GROUPE_ASH", "resource13");
define ("DIVERS","resource14");
define ("DIVERS_INVISIBLE","resource21");
define ("INTERVENANTS", "person1");

// valeurs � titre d'exemple
define ("ERR_DATES_NON_FOURNIES", 1);
define ("DOIT_PASSER_PAR_SON_DOSSIER", 2);
define ("SESSION_EXPIREE", 3);


define ("pdf", 10);
define ("html",11);


define ("TRI_JOUR_SALLE", 501);
define ("TRI_SALLE_JOUR", 502);
define ("TRI_JOUR_GROUPE", 503);
define ("TRI_GROUPE_JOUR", 504);
define ("TRI_JOUR_INTERVENANT",507);
define ("TRI_INTERVENANT_JOUR",508);
define ("HANDLE_GROUPS", 505);
define ("HANDLE_ROOMS", 506);

$constants['_LISTE_TYPE_SALLES'] = array(SALLES_BAT, SALLES_MOL);
$constants['_LISTE_TYPE_GROUPES'] = array("PE1"=>GROUPE_PE1, "PE2"=>GROUPE_PE2,  "PLC1"=>GROUPE_PLC1, "PLC2"=>GROUPE_PLC2,"CPE1"=>GROUPE_CPE1,"CPE2"=>GROUPE_CPE2, "FC"=>GROUPE_FC,"FGC"=>GROUPE_FGC,"ASH"=>GROUPE_ASH,"EtudiantsP4"=>GROUPE_ETU_P4,"Stagiaires en Situation"=>GROUPE_SITUA,"T1"=>GROUPE_T1, "COLLEGES"=>COLLEGES, "Divers"=>DIVERS , "Divers perso"=>DIVERS_INVISIBLE);
$constants['_LISTE_TYPE_GROUPES_INV'] = array(GROUPE_PE1=>"PE1", GROUPE_PE2=>"PE2",  GROUPE_PLC1=>"PLC1", GROUPE_PLC2=>"PLC2",GROUPE_CPE1=>"CPE1",GROUPE_CPE2=>"CPE2", GROUPE_FC=>"FC",GROUPE_FGC=>"FGC", GROUPE_ASH=>"ASH",GROUPE_ETU_P4=>"EtudiantsP4",GROUPE_SITUA=>"Stagiaires en Situation", GROUPE_T1=>"T1",COLLEGES=>"COLLEGES", DIVERS=>"Divers" , DIVERS_INVISIBLE=>"Divers perso");
$constants['_LISTE_TYPE_PERSONNES'] = array(INTERVENANTS);

?>
