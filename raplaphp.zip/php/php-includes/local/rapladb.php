<?php

class rapladb 
{
     function getPlanningByDayByGroups( )
    {
    global $db, $constants;
    $RID=array();
    $sql="SELECT R.RESOURCE_ID FROM RESOURCE_ATTRIBUTE_VALUE R";
    
    $r = $db->query($sql); 
    
      if (isset($r) AND !DB::isError($r))
       {
       
		while($m = $r->fetchRow())
		{
		
		$RID['RESOURCE_ID'][]= $m['RESOURCE_ID'];
		
		}
		
	}
	
	else
          {
           die("Erreur sur la base de donn?es : getPlanningByDayByGroups: requete ($sql)" );
          // // var_dump($sql);
            
         }
         
          
         
        return $RID;        
	
    
    
    }
    
     /* -----------------------------------------------------------------------------------------------------------
        Fonction qui charge les noms des salles en fonction du SITE (Pour le FORMULAIRE)
    -------------------------------------------------------------------------------------------------------------*/
    function getResourcesNamesByType($resourcetypes) // en param?tre on passe le type de resource et si il y en a plusieurs, un tableau
    {
        global $db,$debug;
        $resNames = array();
     
   if($debug)print_r($resourcetypes);
        
        if ( count($resourcetypes) >= 1)
        {        
            $sql = "select RAV.ATTRIBUTE_KEY,RAV.RESOURCE_ID, RAV.VALUE from RESOURCE_ATTRIBUTE_VALUE RAV
                inner join RAPLA_RESOURCE R on R.ID=RAV.RESOURCE_ID
                where RAV.ATTRIBUTE_KEY in ('name')
                AND R.TYPE_KEY IN (";
    
                foreach ($resourcetypes as $type) 
                {
                    $sql .= "'$type',";
                }
                $sql = substr($sql,0,-1) . ") ORDER BY  RAV.VALUE";      
            
            if($debug)var_dump($sql); // sert ? visualiser la requ?te dans le navigateur
        
            $r = $db->query($sql);  // r?sultat de la requ?te
            
            // on remplit la variable resNames
            if (isset($r) AND !DB::isError($r))
            {
                while($m = $r->fetchRow())
                {
                    $resNames[$m['RESOURCE_ID']]= utf8_encode($m['VALUE']);
                   //echo $m['RESOURCE_ID']."=".$m['VALUE']."<br>";
                }
            }
            else
            {
                //die("Erreur sur la base de donn?es :rapladb getResourcesNamesByType" );
               die($resourcetypes);
             //var_dump($resourcetypes);
            }   
        }
        // on renvoie la var resNames
        return $resNames;
    }
    
    /*----------------------------------------------*/
    
    /*getPersonsNamesByType($resourcetypes)  par patrice */
    
    /*------------------------------------------------*/
    function getPersonsNamesByType($resourcetypes)
   
   {
        global $db;
        $resNames = array();
     
        
        
        if ( count($resourcetypes) >= 1)
        {        
            $sql = "select DISTINCT RAV.ATTRIBUTE_KEY,RAV.RESOURCE_ID, RAV.VALUE from RESOURCE_ATTRIBUTE_VALUE RAV
                inner join RAPLA_RESOURCE R on R.ID=RAV.RESOURCE_ID
                where RAV.ATTRIBUTE_KEY in ('surname')
                AND R.TYPE_KEY IN (";
    
                foreach ($resourcetypes as $type) 
                {
                    $sql .= "'$type',";
                }
                $sql = substr($sql,0,-1) . ") ORDER BY  RAV.VALUE";      
            
            //var_dump($sql); // sert ? visualiser la requ?te dans le navigateur
        
            $r = $db->query($sql);  // r?sultat de la requ?te
            
            // on remplit la variable resNames
            if (isset($r) AND !DB::isError($r))
            {
                while($m = $r->fetchRow())
                {
                    $resNames[$m['RESOURCE_ID']]= utf8_encode($m['VALUE']);
                   //echo $m['RESOURCE_ID']."=".$m['VALUE']."<br>";
                }
            }
            else
            {
                //die("Erreur sur la base de donn?es :rapladb getResourcesNamesByType" );
               die($resourcetypes);
             //var_dump($resourcetypes);
            }   
        }
        // on renvoie la var resNames
        return $resNames;
    }
 
    
    
    
    
     
    /* -----------------------------------------------------------------------------------------------------------
        Fonction qui charge les noms des personnes en fonction de leurs types
    -------------------------------------------------------------------------------------------------------------*/    
    
   
    function getInterv() // en param?tre on passe le type de resource et si il y en a plusieurs, un tableau
    {
        global $db;
        $resNames = array();
         $interv_list = array();
         $numelem=0;
         
          
                
          $sql = "SELECT RAV.RESOURCE_ID,RAV.VALUE AS PRENOM, RAV2.VALUE AS NOM
                    FROM RESOURCE_ATTRIBUTE_VALUE RAV
                    INNER JOIN RESOURCE_ATTRIBUTE_VALUE RAV2 ON  RAV.RESOURCE_ID=RAV2.RESOURCE_ID
                    WHERE RAV.ATTRIBUTE_KEY IN ('forename')
                    AND RAV2.ATTRIBUTE_KEY IN ('surname')";  
           
            
           
            
            //var_dump($sql); // sert ? visualiser la requ?te dans le navigateur
        
            $r = $db->query($sql);  // r?sultat de la requ?te
            
            // on remplit la variable resNames
            if (isset($r) AND !DB::isError($r))
            {
                while($m = $r->fetchRow())
                {
                $resNames[]= $m;
                //$_SESSION['form3']['personne'][] =$m['RESOURCE_ID'];
                   
                }
            }
            else
            {
                die("Erreur sur la base de donn?es :rapladb getResourcesNamesByType" );
            }   
        
        
      
        
        // on renvoie la var resNames
        return $resNames;
    }
    
    
  
    /********************
	*  Fonction utilis? pour r?cup?rer tous les information du xml pour les renvoy? rang? dans un tableau
		$start :  date du jour du d?but de la s?lection
		$end : date du jour de fin de la s?lection
		$personFiltre : tableau qui contient les id des intervenants que l'on souhaite filtr? (peut ?tre null)
		$resourceFiltreId : tableau qui contient les id des resources filtr? (principalement les groupes,voire salles particuli?res salles) 
		$resourceFiltreType : tableau qui contient l'id des types de ressources ? filtr? (pour distinguer les sites de molitor et de batignolle)
		$order : tableau qui contient par ordre le nom des champs qui serviront au tri
	*/
		
    function getXml($start , $end ,$personFiltre,$resourceFiltreId,$resourceFiltreType,$order)
    {
		global $db, $conf, $debug, $constants;
		
		$xmlPreRes=NULL;
		$xmlRes=array();
		$planning=array();

        //verifie les dates
        
        $startArray = explode('-', $start); 
        if ( checkdate($startArray[1],$startArray[2],$startArray[0]) == false )
        {
            $start = date('Y-m-d');
        }
        
        $endArray = explode('-', $end); 
        if ( checkdate($endArray[1],$endArray[2],$endArray[0]) == false )
        {
            $end = date('Y-m-d');
        }
            
      
        
       
		/*****
			Pr?pare le tableau de tri dont les ?l?ments seront interpret? pour ?tre choisi comme cl? dans le tableau final (et donc tri ce tableau)
		*****/	
		//la cl? du premier ?l?ment du tableau sera celui qui sera utilis? pour ?tre tri? en premier
		switch($order[0]){
			case 'day':
				$idOrd1='date("Y-m-d",strtotime($xmlRes->start))';
			break;
			case 'name':
				$idOrd1='(string)$xmlRes->name';
			break;
			case 'start':
				$idOrd1='strtotime($xmlRes->start)';
			break;
			case 'end':
				$idOrd1='strtotime($xmlRes->end)';
			break;
			case 'rooms':
				$idOrd1='key($reserv["rooms"])';
			break;
			case 'groups':
				$idOrd1='key($reserv["groups"])';
			break;
			case 'intervenants':
				$idOrd1='key($reserv["intervenants"])';
			break;
			
		}
		
		$i=1;
		$idOrd2=' "  "';
		//la seconde cl? est compos? des autres ?lements du trie (pour faire un asort)
		while(isset($order[$i])){
			switch($order[$i]){
			case 'day':
				$idOrd2.='." ".date("Y-m-d",strtotime($xmlRes->start))';
			break;
			case 'name':
				$idOrd2.='." ".(string)$xmlRes->name';
			break;
			case 'start':
				$idOrd2.='." ".strtotime($xmlRes->start)';
			break;
			case 'end':
				$idOrd2.='." ".strtotime($xmlRes->end)';
			break;
			case 'rooms':
				$idOrd2.='." ".key($reserv["rooms"])';
			break;
			case 'groups':
				$idOrd2.='." ".key($reserv["groups"])';
			break;
			case 'intervenants':
				$idOrd2.='." ".key($reserv["intervenants"])';
			break;
			
			}
		
			$i++;
		}
		
		
		/********
	    *  Lecture du fichier xml pour le mettre dans un tableau
	    *********/	
		//chargement du fichier xml
        
		$xml = simplexml_load_file($conf['raplaxml'] . "&start=" . $start . "&end=" . $end);
		$j=0;

		//parcour du fichier xml block par block pour ne garder que ceux qui nous int?ressent
		foreach ($xml->children() as $block  )
			{
			$xmlPreRes=NULL;

			$trouve=False;
			$videId=True;
			$fin=False;
			
			//applique le filtre sur les groupes et/ou salles 
			if(!empty($resourceFiltreId) ){
				foreach($resourceFiltreId as $resourceFiltre){
					if(!empty( $resourceFiltre)){
						$trouve=False;
						$videId=False;
						if(isset($block->resources) ){
							foreach ($block->resources->resource as $resource){
							
								if(in_array ($resource['relid'],$resourceFiltre)){
									
									$trouve=True;
									break;
								}
							}
						}
						if(!$trouve){
							
							break;
						}
					}
				}
				if(!$videId && !$trouve){
				
					$fin=True;
				}
			}
			$trouve=False;
			$videType=True;
			
			
			//filtre sur les sites (Bat ou Molitor)
			if(!empty($resourceFiltreType) && !$fin ){

				foreach ($resourceFiltreType as $resourceFiltre){
				
					if(!empty( $resourceFiltre)){
						
						$trouve=False;
						$videType=False;
						if(isset($block->resources->resource) ){
							
							foreach ($block->resources->resource as $resource){
								
								if(in_array ($resource['typekey'],$resourceFiltre)){
									
									$trouve=True;
									break;
								}
							}
						}
						if(!$trouve){
							break;
						}
					}
				}
				if(!$videType && !$trouve){
					
					$fin=True;
					
				}
				
			}
			
			$trouve=False;
		
			$xmlRes=NULL;
			
			
			//filtre sur les personnes
			if(!$fin){
				
				if(!empty($personFiltre) ){
					if(isset($block->persons) ){
			
						foreach ($block->persons->person as $person){
							
							if(in_array ($person['relid'],$personFiltre)){
								
								$xmlRes=$block;
								$trouve=True;
								
							}
						}
					}  
				}elseif(!$videType || !$videId){
					$xmlRes=$block;
				}
			}

			//Mise en forme du tableau r?sultat
			if(isset($xmlRes)){
				$reserv= array(
				'start'  => strtotime($xmlRes->start),
				'end' => strtotime($xmlRes->end),
				'name'   => (string)$xmlRes->name,
				'rooms' => rapladb::getDisplayNameRes($xmlRes->resources,$constants['_LISTE_TYPE_SALLES'] ), // va devenir dynamique suite au formulaire
				'groups' => rapladb::getDisplayNameRes($xmlRes->resources,$constants['_LISTE_TYPE_GROUPES'] ),
				'intervenants' => rapladb::getDisplayNameRes($xmlRes->persons, $constants['_LISTE_TYPE_PERSONNES'] )
				);

		   
				$planning[ eval("return $idOrd1;") ][eval("return $idOrd2;").$j++]=$reserv;
				$j++;
			}
			
			
		}//fin de parcour du xml
			
		//tri chaque sous partie suivant la cl? (cr?? pr?c?dement avec les ?l?ments choisie pour le trie
		foreach($planning as $cle=>$valeur){
			ksort($planning[$cle]);
		}
		
		//tri g?n?ral du planning
		ksort($planning);
		

		return $planning;

    }
    
	/*********
	*
	*  filtre pour limiter ? certaine heure du jour 
	*****/
	function filtreXmlJour($hStart = 8,$start = 0,$hEnd=20, $end = 0,$personFiltre,$resourceFiltreId,$resourceFiltreType,$order,$pattern=null)
    {
		global $db, $conf, $debug, $constants;
		
		$planningJour=rapladb::getXml($start, $end,$personFiltre,$resourceFiltreId,$resourceFiltreType,$order);

		$timeDeb=strtotime($start." ".$hStart.":00:00");
		$timeEnd=strtotime($end." ".$hEnd.":00:00");
		
		$planningRes=array();
		foreach ( $planningJour as $jourKey=>$jour){
			foreach($jour as $rsvKey=>$reserv){

				if($reserv['start']<=$timeEnd && $reserv['end']>=$timeDeb ){
					if($pattern!=null){

						$trouve=false;
						while((list($key,$nameRooms) = each($reserv['rooms']) ) && !$trouve){
							if(eregi(".*$pattern.*",$nameRooms['name'])){
								
								$trouve=True;
								$planningRes[$jourKey][$rsvKey]=$reserv;
							}
							
							
						}
					}else{
						$planningRes[$jourKey][$rsvKey]=$reserv;
					}
				}
			}
		}
	
		return $planningRes;
	}
	
    function getDisplayNameRes($xmlObj,$const){
	global $constants,$debug;
	$res=array();
	
	if(!empty($xmlObj)){
	
	

		foreach ($xmlObj->children() as $resource){
			
			if(in_array($resource['typekey'],$const)){
				$keyGen=(string)$resource->displayName;
				foreach($resource->children() as $key=>$value){
					if ($value == 'null' )  //si c'est null on renvoie un champ vide (pour ne pas afficher null)
					{
						$res[$keyGen][(string)$key]='';
					}
					else
					{
						$res[$keyGen][(string)$key]=(string)$value;
					}
			
				}
			}
		}
		
		ksort($res);
			
	}
	return $res;
    }
    
    
    /*-------------------------------------------------------------------------------------------------------------------------------------------------
    * Charge le fichier xml en base de donn?es
    ----------------------------------------------------------------------------------------------------------------------------------*/
    function importPlanningFromRapla($start = 0, $end = 0)
    {
        global $db, $conf, $debug;
        $xml = simplexml_load_file($conf['raplaxml'] . "&start=" . $start . "&end=" . $end);

        //$db->query("BEGIN TRANSACTION");
        
        //DROP pour �tre s�r qu'on n'aura pas de doublon d'?v?nements
       /* $db->query("DROP TABLE BLOCKS");
        $db->query("DROP TABLE ASSOC");            
        */
	
	$r = $db->query("DROP TABLE IF EXISTS BLOCKS;");
	$r = $db->query("DROP TABLE IF EXISTS ASSOC;");
	
        $tablesql = " CREATE TABLE BLOCKS ( ID INTEGER PRIMARY KEY AUTO_INCREMENT, START DATETIME NOT NULL, END DATETIME NOT NULL, NAME TEXT)";
        $tablesql2 = " CREATE TABLE ASSOC (BLOCK_ID INTEGER NOT NULL, RESOURCE_ID INTEGER NOT NULL, RESOURCE_TYPE VARCHAR(40) NOT NULL)";
        //   $tablesql = "CREATE TEMPORARY TABLE BLOCKS ( ID INTEGER PRIMARY KEY AUTO_INCREMENT, START DATETIME NOT NULL, END DATETIME NOT NULL, NAME VARCHAR(50))";
        //     $tablesql2 = "CREATE TEMPORARY TABLE ASSOC (BLOCK_ID INTEGER NOT NULL, RESOURCE_ID INTEGER NOT NULL, RESOURCE_TYPE VARCHAR(40) NOT NULL)";
        $r = $db->query($tablesql);        
        if (isset($r) == false OR DB::isError($r))
        {
            die("Erreur sur la base de donn�es : rapladb importPlanningFromRapla creation table BLOCK ($tablesql)" );
        }
        $r2 = $db->query($tablesql2);
        if (isset($r2) == false OR DB::isError($r2))
        {
            die("Erreur sur la base de donn?es :rapladb importPlanningFromRapla creation table ASSOC ($tablesql2)" );
	}        
	
	
        foreach ($xml->children() as $block )
        {
		//~ $block->start=ajout2H($block->start);
		//~ $block->end=ajout2H($block->end);

	//calcul du d?calage horaire sur le serveur, pour savoir quelle heure afficher
	//~ $zoneDate = new DateTimeZone("Europe/Paris");
	//~ $date=new DateTime($block->start,$zoneDate);
	//~ $offset=timezone_offset_get($zoneDate,$date);
	$offset=0;
	if($debug)echo "<br>D?calage horaire : $offset <br>";
	
	
            // REMPLISSAGE DE LA TABLE BLOCKS
            $sql = "INSERT INTO BLOCKS (START,END,NAME) VALUES (DATE_SUB('$block->start',INTERVAL $offset SECOND),DATE_SUB('$block->end',INTERVAL $offset SECOND),'" . addslashes($block->name) . "')";
            $rf1 = $db->query($sql);
            if (isset($rf1) == false OR DB::isError($rf1))
            {
                echo substr($sql,0,-1);// supprimer le dernier point
                die("Erreur sur la base de donn?es: rapladb importPlanningFromRapla remplissage table BLOCK ($sql)" );
            }

            $blockid = $db->getOne("SELECT LAST_INSERT_ID()");

            //
            if ($block->persons->person)
            {
                // REMPLISSAGE DE LA TABLE ASSOC
                $assocsql = "INSERT INTO ASSOC VALUES ";
                foreach ($block->persons->person as $person)
                {
                    $assocsql = $assocsql . "($blockid, " . $person['relid'][0] . ", '" . $person['typekey'][0] . "'),";
                }
                $rf = $db->query( substr($assocsql,0,-1) );//suppr derni?re virgule
                if (isset($rf) == false OR DB::isError($rf))
                {
                    echo $sql, $assocsql;
                    die("Erreur sur la base de donn?es rapladb importPlanningFromRapla remplissage table ASSOC type person" );
                }
            }
            
            if ($block->resources->resource)
            {
                $assocsql = "INSERT INTO ASSOC VALUES ";
                foreach ($block->resources->resource as $resource)
                {
                    $assocsql = $assocsql . "($blockid, " . $resource['relid'][0] . ", '" . $resource['typekey'][0] . "'),";
                }
                $rf = $db->query( substr($assocsql,0,-1) );
                if (isset($rf) == false OR DB::isError($rf))
                {
                    echo $sql, $assocsql;
                    die("Erreur sur la base de donn?es rapladb importPlanningFromRapla remplissage table ASSOC type resource" );
                }
            }            


        }
    }
    
    

     function getAfficheByEcran (){
		global $db,$debug;
		
		$sql=" SELECT e.nom, e.ip, e.site, f.id, f.lib, f.type, f.nomfich FROM _ecran  e left join  (_fichier f , _affiche a ) ON ( e.nom = a.nomEcran AND a.idFichier = f.id )";
		$res = $db->query( $sql);
		
		$retour=Array();
		
		 if (isset($res) AND !DB::isError($res))
		{
			while($ecr = $res->fetchRow())
			{
				if(!isset($retour[$ecr["nom"]])) $retour[$ecr["nom"]]=Array();
				
				if($ecr["type"]!=NULL){
					$retour[$ecr["nom"]][$ecr["type"]][$ecr["id"]]=Array("lib"=>$ecr["lib"],"nomfich"=>$ecr["lib"]);
				}
				
			
			   
			}
		}
		else
		{
			die("Erreur sur la base de donn?es :rapladb getAfficheByEcran" );
		}   
     
		return $retour;	
     }
     
     
      function getAffichefich (){
		global $db,$debug;
		
		$sql=" SELECT f.id, f.lib, f.type, f.nomfich FROM  _fichier f  ";
		$res = $db->query( $sql);
		
		
		 if (isset($res) == false OR DB::isError($res))
                {
                    echo $sql;
                    die("Erreur sur la base de donn?es rapladb getAffichefich" );
                }
		
		$retour=Array();
		
		
		 if (isset($res) AND !DB::isError($res))
		{
			while($fich = $res->fetchRow())
			{
				$retour[$fich["type"]][$fich["id"]]= $fich["lib"];
			}   
		}
		else
		{
			die("Erreur sur la base de donn?es :rapladb getAfficheAuto" );
		}   
     
		return $retour;	
     }
   
   function  getAfficheEcran ($nom){
	global $db,$debug;
	$sql=" SELECT e.nom, e.ip, e.site, f.id, f.lib, f.type, f.nomfich FROM _ecran  e left join  (_fichier f , _affiche a ) ON ( e.nom = a.nomEcran AND a.idFichier = f.id ) WHERE e.nom ='$nom' ";
		$res = $db->query( $sql);
		
		$retour=Array();
		
		 if (isset($res) AND !DB::isError($res))
		{
			while($ecr = $res->fetchRow())
			{
				if(!isset($retour[$ecr["ip"]])){
					$retour["ip"]=$ecr["ip"];
					$retour["site"]=$ecr["site"];
				}
				
				if($ecr["type"]!=NULL){
					$retour[$ecr["type"]][$ecr["id"]]=Array("lib"=>$ecr["lib"],"nomfich"=>$ecr["nomfich"]);
				}
				
			
			   
			}
		}
		else
		{
			die("Erreur sur la base de donn?es :rapladb getAfficheByEcran" );
		}   
     
		return $retour;

    }
    
    function  getAfficheEcranFich ($nom,$idFich){
	global $db,$debug;
	$sql=" SELECT e.nom, e.ip, e.site, f.id, f.lib, f.type, f.nomfich FROM _ecran  e inner join  (_fichier f , _affiche a ) ON ( e.nom = a.nomEcran AND a.idFichier = f.id ) WHERE f.id=$idFich AND e.nom ='$nom' ";
		$retour = $db->getRow( $sql) or die("Erreur sur la base de donn?es :rapladb getAfficheEcranFich : ".$retour->getMessage() );
		
		return $retour;

    }
    
    
    
    function getIPEcran ($nom){
	global $db,$debug;
	
	$sql="SELECT ip from _ecran WHERE nom='$nom'";
	$res = $db->query( $sql);
	
	if (isset($res) AND !DB::isError($res))
	{
		$IP = $res->fetchRow();
		$IP=$IP['ip'];
	}else
	{
			die("Erreur sur la base de donn?es :rapladb getIPEcran" );
	}  
	
	
	return $IP;
    }
   
   function delAfficheLien($idFich,$nomEcran){
   		global $db;
	$sql="DELETE FROM _affiche WHERE nomEcran='$nomEcran' AND idFichier=$idFich";
	$rdel= $db->query( $sql);
	if (isset($rdel) == false OR DB::isError($rdel))
	{
	    echo $sql;
	    die("Erreur sur la base de donn?es rapladb delAfficheLien" );
	}
   
   }
   
   function InsAfficheLien($idFich,$nomEcran){
   		global $db;
	$sql="INSERT IGNORE INTO _affiche (nomEcran,idFichier) VALUES ('$nomEcran',$idFich)";
	$rdel= $db->query( $sql);
	if (isset($rdel) == false OR DB::isError($rdel))
	{
	    echo $sql;
	    die("Erreur sur la base de donn?es rapladb InsAfficheLien" );
	}
	
	
   
   }
   
   
   function  addFich($nom){
		global $db;
		$sql="select * from _fichier where nomfich = '$nom'";
		$rSelect= $db->query( $sql);
		
		
		
		
		
		if(!$rSelect->fetchRow()){
			$sql="INSERT IGNORE INTO _fichier  (lib,type, nomfich) values ('". basename($nom,'.pdf') ."','manu', '".$nom ."')";
			$rIns= $db->query( $sql);
	
			if (isset($rIns) == false OR DB::isError($rIns))
			{
				
				return 0;
		
			}else{
				return 2;
			}
		}else{
			return 1;
		}
    }



function delLien($idFich){
	global $db;
	
	$db->autocommit(FALSE);
	$db->query('BEGIN');
	$sql="select * from _fichier where id = '$idFich' for update";
	$rSelect= $db->query( $sql);

	$fichier=$rSelect->fetchRow();
	if($fichier){
		$sql="DELETE from _fichier where id = '$idFich'";
		$rDel= $db->query( $sql);

		if (isset($rDel) == false OR DB::isError($rDel))
		{
			 $db->query('rollback');
			
			return 0;
	
		}else{
			return $fichier;
		}
	}else{
		$db->query('rollback');
		
		return 0;
	}

}





}


  

?>
