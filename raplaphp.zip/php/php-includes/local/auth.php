<?php
class auth {

   
    
    /*
    * authenticate est la fonction appelée pour procéder à l'authentification.
    * elle n'est pas sensée recevoir de mot de passe.
    * 
    *
    * retourne la fiche de la personne si l'authentification a réussi, et sinon, le booléen false
    */
    
    function authenticate()
    {
      global $conf;
      phpCAS::setDebug();

      // initialize phpCAS        
      phpCAS::client(CAS_VERSION_2_0,$conf['serveurSSO'],443,$conf['serveurSSORacine'], false);
      //phpCAS::setLang('french');

      
      
     //ajout dans planning car probleme de conf 
     phpCAS::setNoCasServerValidation(); 
      
      // force CAS authentication
      phpCAS::forceAuthentication();
      $uid=phpCAS::getUser();
      
       return $uid;
    }
    
    function desauthenticate()
    {
        
    }
}
?>