<?php

class form {

    function getGroups()
    {
        global $db,$constants;
        $groups = array();
        
        //$groupTypes = array( GROUPE_PE1 => 'PE1', GROUPE_PE2 => 'PE2', GROUPE_PLC1 => 'PLC1',GROUPE_PLC2 => 'PLC2', GROUPE_FC => 'FC',GROUPE_FGC => 'FGC'); 
        $groupTypes =  $constants['_LISTE_TYPE_GROUPES_INV'];
	
        foreach ( $groupTypes as $groupType => $groupName )
        {
            $groups[$groupType] = array(
                'name' => $groupName,
                'list' => rapladb::getResourcesNamesByType( array( $groupType ) )
                );
        }        
        
        return $groups;
    }
    
    
    function getIntervenants()
    {//fait par patrice

    global $db;
   // $tabintervenants=array();
    //$ints = array(RESOURCE_TYPE=> 'person1');
    
    
    //$tabintervenants=rapladb::getResourcesNamesByType($ints);
    $tabintervenants=rapladb::getInterv();
    /*foreach ( $ints as $restype => $name )
        {
            $tabintervenants[$restype] = array(
                'name' => $name,
                'list' => rapladb::getResourcesNamesByType( array( $restype) )
                );
        }       */ 

       
       //var_dump($tabintervenants);
       

        
        
       
        /*foreach ( $ints as $restype => $name )
            {
                $tabintervenants[$restype] = array(
                    'name' => $name,
                    'list' => rapladb::getResourcesNamesByType( array( $restype) )
                    );
            }       */ 
            
            return $tabintervenants;
    
      }
    
    
    function getPersons()
    {//fait par patrice
        $tabintervenants=array();
        $tabintervenants=rapladb::getInterv();
        
    return $tabintervenants;
    }
   
    function getViewModes()
    {
	    return array( pdf => 'pdf',html => 'html');
        
    }
    
    function getRoomTypes()
    {
	    return array( SALLES_MOL => 'Molitor', SALLES_BAT => 'Batignolles' );
        
    }
    /*
    * Retourne les types de personnes, en utilisant les constantes d�finies dans constants.php
    */    
    function getPersonTypes()
    {
        return array(INTERVENANTS=>' Intervenants');
       
    }
    
    function getSortForRooms()
    {
        return array(
            TRI_JOUR_SALLE => "par jour, par salle",
            TRI_SALLE_JOUR => "par salle, par jour"
        );
    }
    
    function getSortForGroups()
    {
        return array(
            TRI_JOUR_GROUPE => "par jour, par groupe",
            TRI_GROUPE_JOUR => "par groupe, par jour"
        );
    }
    
    
    function getSortForIntervenants()
    {
        return array(
            TRI_JOUR_INTERVENANT => "par jour, par intervenant",
            TRI_INTERVENANT_JOUR => "par intervenant, par jour"
        );
    }
    
   
    
    function test()
    {
        global $db;
        /*$sql = "SELECT * FROM RAPLA_RESOURCE";*/
        //format date dans block:2007-10-02 11:00:00

       // $sql = "SELECT * FROM BLOCKS";
       $sql = "INSERT INTO BLOCKS (START,END,NAME) VALUES ('2007-10-02 11:00:00','2007-10-02 14:00:00','cours NTIC')";
        $resources = array();
        
        $r = $db->query($sql);  // r�sultat de la requ�te
        $sql = "SELECT * FROM BLOCKS";
        if ( isset($r) AND ! DB::isError($r) )
        {
            while($m = $r->fetchRow())
            {        
                $resources[] = $m ;
                echo "IDBLOCK:".$m['ID']."<br>";
                echo "DEBUT:".$m['START']."<br>";
                echo "FIN:".$m['END']."<br>";
                echo "EVENEMENT".$m['NAME']."<br>";
                
            }
        }
        
        return $resources;
    }
}

?>