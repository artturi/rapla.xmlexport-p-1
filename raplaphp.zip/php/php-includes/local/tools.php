<?php

class tools
{     
    
    function setDefaults($form,$sites=array())
    {
        global $conf,$uid;
        switch ($form)
        {
            case "form1" :
                $_SESSION[$form]['sortMethod'] = TRI_JOUR_SALLE;
                break;
            case "form2" :
                $_SESSION[$form]['sortMethod'] = TRI_JOUR_GROUPE;
                break;
            case "form3" :
                $_SESSION[$form]['sortMethod'] = TRI_JOUR_INTERVENANT; 
                break;
            case 'formEcran' :
                $_SESSION[$form]['hStart'] = 8;
                $_SESSION[$form]['hEnd'] = 19;
                
                break;
            
        }
        $_SESSION[$form]['start'] = date("j/n/Y",mktime(0, 0, 0, date("m")  , date("d"), date("Y")) );
        $_SESSION[$form]['end'] = date("j/n/Y",mktime(0, 0, 0, date("m")  , date("d")+7, date("Y")) );
        
        $_SESSION[$form]['viewmode'] = html;
        $_SESSION[$form]['roomType'] =$sites;

      

    }
    
    function dateFr2ISO($date)
    {
        $r = preg_match("/(\d{1,2})\/(\d{1,2})\/(\d{4})/", $date, $matches);        
        return $matches[3] . "-" . $matches[2] . "-" . $matches[1];
    }
    
    function change_mois($date,$sens)
    {
        return date('j/n/Y',strtotime($sens,strtotime(tools::dateFr2ISO($date))));;
    }

    function dateEN($date)
    {
        switch (strlen($date)){
            case 9:
                return substr($date,3,2).'/1/'.substr($date,-4);
                break;
            default:
                return substr($date,3,1).'/1/'.substr($date,-4);
                break;
        }
    }
    
    function dateFR($date,$format )
	{
	   setlocale( LC_TIME, "fr" );
	   return strftime($format, strtotime(tools::dateFr2ISO($date)));
	}
}

?>
