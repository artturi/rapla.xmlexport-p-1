<?php

class checks
{
/* 
    function getPage()
    {
        $page = (isset($_GET['page']) == false)? 'default' : $_GET['page'] ;
       $allowToResponsable = array('accueil', 'aff');
    
        if ( in_array($page, $allowToResponsable)  )
        {
            return 'index';
        }
       
        return $page;
    }
    */ 
    
    function checkDateParams()
    {
        if (array_key_exists("start", $_GET) == false OR array_key_exists("end", $_GET) == false )
            return ERR_DATES_NON_FOURNIES;
        else return OK;
    
    }
    
    function getAction()
    {
	$action = (isset($_POST['action']) == false)? 'default' : $_POST['action'] ;
	$allowToResponsable = array('accueil', 'aff');
	return $action;
    }
	
	
	function  testVide($webRoot,$planning){
		if(empty($planning)){
				
			$path = $webRoot.'/?page=ResVide';
			header( "Location: {$path}");
			
		}
		return 1;
	}
}

?>