<?php
/**
 *  Fichier de configuration de l'application
**/
// Reporting : utile au déboggage
ini_set("error_reporting", E_ALL);

require_once (  '/var/www/svnexp/planning/test/php-includes/local/constants.php') ;
//  Configuration de l'application
$conf = array(
  'appRoot' => '/var/www/svnexp/planning/test',  // dossier de stockage local
  'webRoot' => 'http://planning.opaque.paris.iufm.fr/test', //  chemin complet de l'application sur le web
   'managers' => array('login1','login2','login3','login4','uid5','uid6'),
    'sitePref'=>array('login2'=>array(SALLES_MOL,SALLES_BAT),'login3'=>array(SALLES_MOL,SALLES_BAT),'login4'=>array(SALLES_MOL),'uid5'=>array(SALLES_BAT),'uid6'=>array(SALLES_MOL),'login7'=>array(SALLES_MOL)),
  //~ 'raplaxml' => 'http://192.168.5.21:8051/rapla?page=xml&format=limited',
  'raplaxml' => 'http://rapla_ip:8051/rapla?page=xmlexport&user=admin',
   'scriptFile' => '/var/www/svnexp/planning/test/www/scripts/',
  'upFile' => '/var/www/svnexp/planning/test/www/files/',
  'serveurSSO'=> 'sso.paris.iufm.fr',
  'serveurSSOPort'=>443,
  'serveurSSORacine'=>'/cas',
  'ipClt' => array('ip1','ip2','ip3','ip4','ip5','ip6'),
  
  //ldap
  'serveurLDAP2'=>"ldap://ldap-fqdn1",
  'serveurLDAP1'=>"ldap://ldap-fqdn2",
  'dnUser'=>"uid=login,ou=special users,dc=our,dc=domain,dc=fr",
  'dnPass'=>"pass"
);

$database = array(
    'raplaro' => 'mysql://rapla-user:pass@mysql-ip/rapla'
);

// on n'affiche pas les erreurs � l'�cran pour le site en production
ini_set('display_errors', false);

//  Configuration du syst�me de templates
$smartyConf = array(
  'template_dir'   => 'templates',
  'compile_dir'    => 'precache',
  'config_dir'     => 'config',
  'plugins_dir'     => 'plugins',
  'caching'        => false,
  'cache_dir'      => 'cache',
  'cache_lifetime' => 6000,
  'use_sub_dirs'   => false,
  'compile_check'  => true,
  'force_compile'  => true
);


?>