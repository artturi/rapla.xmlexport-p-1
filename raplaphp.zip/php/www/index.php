<?php

    //lecture de la conf
    require_once('inc.php');

   // require('fpdf.php');
    // verif des droits d'acces (superflus ?)
    //$page = checks::getPage();

	
	
	
    $page = (isset($_GET['page']) == false)? 'default' : $_GET['page'] ;
    $format = (isset($_GET['format']) == false)? 'html' : $_GET['format'] ;
    
    // lecture des erreurs pass�es en param�tres dans l'url
    if ( isset($_GET['err']) == true AND strlen($_GET['err']) > 0 )
    {
        $s->assign('erreurs', erreurs::msgErreurs($_GET['err']));
    }
    $s->assign('url',$conf['webRoot']);
	
	/* pour l'instant j'enl�ve ce menu pour �viter certains probl�me */
	//verifie si c'est unnmanager qui a le droit d'acc�der au menu de conf des tv
	if($_SESSION['utilisateur']->manag == true ){
		$s->assign('manag',true);
	}else{
	   unset($constants['_LISTE_TYPE_GROUPES']["Divers perso"]);
	   unset($constants['_LISTE_TYPE_GROUPES_INV'][DIVERS_INVISIBLE]);
	}
    
    if($_SESSION['utilisateur']->interv == true )
    {
        $s->assign('interv',true);
    
    }
	
	
	// echo $page;
    // suivant le nom de la page pass�e en param�tre:
    switch( $page )
    {
        case 'index':
        case 'default':
            $s->display('index.tpl');
            break;

        case 'blocks2db':
          rapladb::importPlanningFromRapla('2008-06-01', '2009-06-01');
          $d->display('index.tpl');
          break;
           
        case 'form1': // APPEL DU FORMULAIRE DU PLANNING PAR SALLE


			if ( isset($_SESSION['form1']) == false ) {
                
				// $listRoom=rapladb::getResourcesNamesByType( array($conf['sitePref'][$uid]) );
				
				tools::setDefaults('form1',$conf['sitePref'][$uid]);

			}

		
			$s->assign("roomTypes", form::getRoomTypes() );
			$s->assign("viewmodes", form::getViewModes() );
			$s->assign("rooms",rapladb::getResourcesNamesByType( array($_SESSION['form1']['roomType']) ));
			$s->assign('groups', form::getGroups() );
			$s->assign("sortMethods", form::getSortForRooms() );
			$s->assign("handleGroups", array( HANDLE_GROUPS => 'Tenir compte des groupes') );
			$s->display('form1.tpl');
			break;     
        
        
        
        case 'form2': // APPEL DU FORMULAIRE DU PLANNING PAR GROUPE
	  
			if ( isset($_SESSION['form2']) == false ) {

				// $listRoom=rapladb::getResourcesNamesByType( array($conf['sitePref'][$uid]) );

				tools::setDefaults('form2',$conf['sitePref'][$uid]);

			}



			$s->assign('displayPage','block');
			$s->assign('groups', form::getGroups() );
			$s->assign("roomTypes", form::getRoomTypes() );
			$s->assign("viewmodes", form::getViewModes() );
			$s->assign("rooms", rapladb::getResourcesNamesByType( array($_SESSION['form2']['roomType']) ));
			$s->assign("sortMethods", form::getSortForGroups() );               
			$s->assign("handleRooms", array( HANDLE_ROOMS => 'Tenir compte des salles') );
			$s->display('form2.tpl');
			break;        

        case 'form3': // APPEL DU FORMULAIRE DU PLANNING PAR INTERVENANT
			if ( isset($_SESSION['form3']) == false ) tools::setDefaults('form3',$conf['sitePref'][$uid]);
			//$s->assign("personTypes", form::getPersonTypes());
			// $s->assign('persons', form::getPersons());//form::getPersons() fait par patrice
			$s->assign("sortMethods", form::getSortForIntervenants());
			$s->assign("personTypes", form::getPersonTypes());
			$s->assign("viewmodes", form::getViewModes() );
			$s->assign("roomTypes", form::getRoomTypes() );
			// $s->assign("rooms", rapladb::getResourcesNamesByType( array($_SESSION['form2']['roomType']) ) );
			$s->assign('persons',rapladb::getPersonsNamesByType($constants['_LISTE_TYPE_PERSONNES']));
			$s->display('form3.tpl');
			break;

        /*affichage du planning du jour selectionn� par ressource */
		case 'formEcran' :
			if ( isset($_SESSION['formEcran']) == false ) tools::setDefaults('formEcran',$conf['sitePref'][$uid]);
			//if($debug)print_r($constants['_LISTE_TYPE_GROUPES'] );
			$s->assign('groups', $constants['_LISTE_TYPE_GROUPES'] );
			$s->assign("roomTypes", form::getRoomTypes() );
			$s->assign("sortMethods", form::getSortForGroups() );               
			$s->assign("handleRooms", array( HANDLE_ROOMS => 'Tenir compte des salles') );
			$s->display('formEcran.tpl');
	  
	  
			break;

		case 'tv' :
 
  
			 if(in_array($uid,$conf ["managers"])){
				$tv=rapladb::getAfficheByEcran();
				//$tv=Array('atele1'=>Array('auto'=>Array('pe2'=>"PE2", 'plc2'=>"PLC2"),'manu'=>Array()),'atele2'=>Array('auto'=>Array('pe1'=>"PE1", 'plc1'=>"PLC1"),'manu'=>Array()));
				$fichier=rapladb::getAffichefich();
				
				//$automatique=Array('pe1'=>"PE1",'pe2'=>"PE2",'plc1'=>"PLC1",'reunion'=>"Reunion");
				if(isset($_GET["ecran"]))$TelePrinc=$_GET["ecran"];
				else $TelePrinc=key($tv);
			
				//$manuel=Array("Essai.pdf");
				$s->assign('firstTV',$TelePrinc);
				$s->assign('tv',$tv);
				$s->assign('fichier',$fichier);
				
				$s->display('tv.tpl');
			}else{
				$path = $webRoot.'/?';
				header( "Location: {$path}");
			}
			break;

		case 'viewTv' :
			$tv=rapladb::getAfficheByEcran();
			if(isset($_GET["ecran"]))$TelePrinc=$_GET["ecran"];
			else $TelePrinc=key($tv);
			$s->assign('firstTV',$TelePrinc);
			$s->assign('tv',$tv);
			$s->display('viewtv.tpl');
			break;

            
            
            
        case 'getpdf':
            //$_SESSION['ids'] = $_GET['liste_ids'];
			//$path = $webRoot . '/getpdf.php?page=' . $_GET['mode']."&viewmedia=form1" ;
			$path = $webRoot . '/treatpdf.php?page=' . $_GET['mode']."&viewmedia=form1" ;
			header("Location: {$path}");

			exit();
			break;     

      

      
             
	
             
             
		case 'dayRoom': // Affichage du planning par jour, en fonction du type de salle: BAT OU MOLITOR
		case 'roomDay':	
														   //~ $groupedIds) );
			if($page=="dayRoom"){					    
				$order[0]='day';					    
				$order[1]='rooms';
			}else{
				$order[0]='rooms';
				$order[1]='day';
			}
			$order[2]='start';
			$order[3]='end';
			$order[4]='name';
		
		
			//r�cup�re les groupe 
			$groupedIds = array();
			if ( isset($_SESSION['form1']['handleGroups']) == true && $_SESSION['form1']['handleGroups'][0] == HANDLE_GROUPS )
			{
				if(isset($_SESSION['form1']['group'])){
					foreach ($_SESSION['form1']['group'] as $groupParent){ 
						if(!isset($_SESSION['form1']['groups'][$groupParent])){
							$groupList=rapladb::getResourcesNamesByType( array($groupParent) );

							foreach ($groupList as $id=>$name){
								array_push($groupedIds,$id);
							}
						}
					}
				}
				
				if(isset( $_SESSION['form1']['groups'])){
					foreach ( $_SESSION['form1']['groups'] as $groupType => $groupList )
								$groupedIds = array_merge($groupedIds, $groupList);
				}
			}

		

			/* R�cup�ration des donn�es � afficher ordonn� dans un tableau */
			$planning=array(); //pour les salle de Molitor - puis l'ensemble
			$planning2=array();//pour les salles de Batignolle 

			//Suivant le site (molitor, batignolle), je r�cup�re de facon s�par� pour ne pas m�langer si selectionn certaine salle d'un site et tous l'autre site
			if(in_array(SALLES_MOL,$_SESSION['form1']['roomType'])){
				if(isset($_SESSION['form1']['rooms'])){
					$listeResource=array($_SESSION['form1']['rooms'][SALLES_MOL],$groupedIds);
				}else{
					$listeResource=array($groupedIds);
				}
				$planning=rapladb::getXml(tools::dateFr2ISO($_SESSION['form1']['start']), tools::dateFr2ISO($_SESSION['form1']['end']),NULL,$listeResource,array(array(SALLES_MOL)),$order);
			} 
			
			if(in_array(SALLES_BAT,$_SESSION['form1']['roomType'])){
				if(isset($_SESSION['form1']['rooms'])){
					$listeResource=array($_SESSION['form1']['rooms'][SALLES_BAT],$groupedIds);
				}else{
					$listeResource=array($groupedIds);
				}
				$planning2=rapladb::getXml(tools::dateFr2ISO($_SESSION['form1']['start']), tools::dateFr2ISO($_SESSION['form1']['end']),NULL,$listeResource,array(array(SALLES_BAT)),$order);
			}
			//r�unie les salles de Molitor et de Batignolles
			
			$planning=array_merge_recursive($planning,$planning2);
			if(checks::testVide($webRoot,$planning)){
				
				
				
				//~ $s->assign('roomNames',array_keys($planning));

				//si on affiche un pdf
                if ($format == 'pdf' )
                {
                  
                    $nom_fichier = 'planningSalle.pdf';
                    $pdf = new PlanningPDF($page,$planning);
                  
                
                }
                else   //format html
                {
                
                    $titre="Du ".$_SESSION['form1']['start']." au ".$_SESSION['form1']['end'];
                    $s->assign('titre',$titre);
                    $s->assign('planning',$planning);
                    if($page=="dayRoom"){	
                        $s->display('displ_day_room.tpl');
                    }else{
                        $s->display('displ_room_day.tpl');
                    }
                }
			}
			break;      

        case 'dayGroup': // Affichage du planning par jour, en fonction du GROUPE EN COURS DE CONSTRUCTION      
        case 'groupDay':
			
	

		
			if($page=="dayGroup"){					    
				$order[0]='day';					    
				$order[1]='groups';
			}else{
				$order[0]='groups';
				$order[1]='day';
			}
			$order[2]='start';
			$order[3]='end';
			$order[4]='name';
		
		
			//r�cup�re les groupe 
			$roomIds = array();
			$groupedIds = array();
			// if ( isset($_SESSION['form2']['handleRooms']) == true && $_SESSION['form2']['handleRooms'][0] == HANDLE_ROOMS )
                // $roomIds = $_SESSION['form2']['rooms'];
            if (isset($_SESSION['form2']['group'])){
				foreach ($_SESSION['form2']['group'] as $groupParent){ 
					if(!isset($_SESSION['form2']['groups'][$groupParent])){
						$groupList=rapladb::getResourcesNamesByType( array($groupParent) );

						foreach ($groupList as $id=>$name){
							array_push($groupedIds,$id);
						}
					}
				}
			}
			if(isset($_SESSION['form2']['groups'])){
				foreach ($_SESSION['form2']['groups'] as $group => $groupList){	
					$groupedIds = array_merge($groupedIds, $groupList);
				}
			}
			/* R�cup�ration des donn�es � afficher ordonn� dans un tableau */
			$planning=array(); //pour les salle de Molitor - puis l'ensemble
			$planning2=array();//pour les salles de Batignolle 

			//Suivant le site (molitor, batignolle), je r�cup�re de facon s�par� pour ne pas m�langer si selectionn certaine salle d'un site et tous l'autre site
			if(in_array(SALLES_MOL,$_SESSION['form2']['roomType'])){
				if(isset($_SESSION['form2']['rooms'])){
					$listeResource=array($_SESSION['form2']['rooms'][SALLES_MOL],$groupedIds);
				}else{
					$listeResource=array($groupedIds);
				}
				$planning=rapladb::getXml(tools::dateFr2ISO($_SESSION['form2']['start']), tools::dateFr2ISO($_SESSION['form2']['end']),NULL,$listeResource,array(array(SALLES_MOL)),$order);
			
			} 
			
			if(in_array(SALLES_BAT,$_SESSION['form2']['roomType'])){
				if(isset($_SESSION['form2']['rooms'])){
					$listeResource=array($_SESSION['form2']['rooms'][SALLES_BAT],$groupedIds);
				}else{
					$listeResource=array($groupedIds);
				}
				$planning2=rapladb::getXml(tools::dateFr2ISO($_SESSION['form2']['start']), tools::dateFr2ISO($_SESSION['form2']['end']),NULL,$listeResource,array(array(SALLES_BAT)),$order);
			}
			//r�unie les salles de Molitor et de Batignolles
			
			$planning=array_merge_recursive ($planning,$planning2);
			
			if(checks::testVide($webRoot,$planning))
            {
                //si on affiche un pdf
                if ($format == 'pdf' )
                {
                  
                    $nom_fichier = 'planningGroup.pdf';
                    $pdf = new PlanningPDF($page,$planning);
                  
                
                }
                else   //format html
                {
                    $s->assign('planning',$planning);
                    
                    $titre="Du ".$_SESSION['form2']['start']." au ".$_SESSION['form2']['end'];
                    $s->assign('titre',$titre);
                    //~ $s->assign('roomNames',array_keys($planning));

                                            
                    if($page=="dayGroup"){	
                        $s->display('displ_day_group.tpl');
                    }else{
                        $s->display('displ_group_day.tpl');
                    }
                }
			}
			break;      
                        
        case 'dayPerson':
        case 'personDay':
		
			if($page=='dayPerson'){
				$order[0]='day';
				$order[1]='intervenants';
			}else{
				$order[0]='intervenants';
				$order[1]='day';
			}
			$order[2]='start';
			$order[3]='end';
			$order[4]='name';


			$planning=array();
			$planning2=array();


			//Suivant le site (molitor, batignolle), je r�cup�re de facon s�par� pour ne pas m�langer si selectionn certaine salle d'un site et tous l'autre site
			if(in_array(SALLES_MOL,$_SESSION['form3']['roomType'])){
			
				$planning=rapladb::getXml(tools::dateFr2ISO($_SESSION['form3']['start']), tools::dateFr2ISO($_SESSION['form3']['end']),$_SESSION['form3']['persons'],array(NULL),array(array(SALLES_MOL)),$order);
			} 
			if(in_array(SALLES_BAT,$_SESSION['form3']['roomType'])){
         
				$planning2=rapladb::getXml(tools::dateFr2ISO($_SESSION['form3']['start']), tools::dateFr2ISO($_SESSION['form3']['end']),$_SESSION['form3']['persons'],array(NULL),array(array(SALLES_BAT)),$order);
			}
      
			$planning=array_merge_recursive($planning,$planning2);
			if(checks::testVide($webRoot,$planning)){
                //si on affiche un pdf
                if ($format == 'pdf' )
                {
                  
                    $nom_fichier = 'planningIntervenant.pdf';
                    $pdf = new PlanningPDF($page,$planning);
                  
                
                }
                else   //format html
                {
    
                    $s->assign('planning',$planning);
                    
                    
                    $titre="Du ".$_SESSION['form3']['start']." au ".$_SESSION['form3']['end'];
                    $s->assign('titre',$titre);
                        
                    if($page=='dayPerson'){
                        $s->display('displ_day_person.tpl'); 
                    }else{
                         // $s->assign('persNames',array_keys($planning));
                        $s->display('displ_person_day.tpl'); 
                    
                    }
                }
			}
		 
			break;
             
          
        case 'globalPdf' :
     
           
            if ( isset($_SESSION['unpdf'] ) == true )
            {
                $_GET=$_SESSION['unpdf'];
                $_SESSION['unpdf'] = NULL;
            }
            
            
            
     
            $order[0]='day';					    	
            $order[1]='start';
            $order[2]='end';
            $order[3]='groups';	
            $order[4]='name';		

                    //r�cup�re les groupes 
            $roomIds = array();
            $groupedIds = array();
            foreach ($_GET['group'] as $groupParent){ 
                
                $groupList=rapladb::getResourcesNamesByType( array($groupParent) );
                
                foreach ($groupList as $id=>$name){
                    array_push($groupedIds,$id);
                }
                
            }
        
             
            $hStart =$_GET['hStart'];
            $hEnd =$_GET['hEnd'];

            
            $site=$_GET['site'];
            
            
            @$pattern=$_GET['pattern'];
          
            $planning=Array();
          
            if($debug)
            {
                echo "<br>ds<br>";
                print_r($_GET);
            }
            if(isset($_GET['start']) and $_GET['start']!=NULL){
                //~ $start = date('Y-m-d') ; 
                //~ $end =  date('Y-m-d') ;
                $start =tools::dateFr2ISO($_GET['start']);
                $end =tools::dateFr2ISO($_GET['start']);
                //~ $end =tools::dateFr2ISO($_GET['start']);
                if($debug) echo "<br> start = $start <br> start2 = $start2 <br>";
            }else{
                $start = date('Y-m-d') ; //. ' 06:30:00';
                $end =  date('Y-m-d') ; //. ' 12:30:00';
            } 
            


            
            /* R�cup�ration des donn�es � afficher ordonn� dans un tableau */
            $planning=array(); //pour les salle de Molitor - puis l'ensemble
            $planning2=array();//pour les salles de Batignolle 
            
            //Suivant le site (molitor, batignolle), je r�cup�re de facon s�par� pour ne pas m�langer si selectionn certaine salle d'un site et tous l'autre site
            if(in_array(SALLES_MOL,$site)){
                
                $planning=rapladb::filtreXmlJour($hStart,$start,$hEnd, $end,NULL,array($groupedIds),array(array(SALLES_MOL)),$order,$pattern);
            
            } 
            if(in_array(SALLES_BAT,$site)){
                
                $planning2=rapladb::filtreXmlJour($hStart,$start,$hEnd, $end,NULL,array($groupedIds),array(array(SALLES_BAT)),$order,$pattern);
            } 

            //r�unie les salles de Molitor et de Batignolles
            
            $planning=array_merge_recursive ($planning,$planning2);
             
                // print_r($planning);
            if($debug) { 
                echo "<br>planning : "; 
                print_r($planning);
            }   
            
            if (checks::testVide($conf["webRoot"],$planning)){
        
                $nom_fichier = 'planning.pdf';
                $pdf = new PlanningPDF($page,$planning,$hStart,$hEnd);
                // if(isset($_GET['addPage']) && $_GET['addPage']==true){
                
                    // $this->planJourAdd($planning,$hStart,$hEnd);
                // }else{
                    // $this->planJour($planning,$hStart,$hEnd);
                // }
                
            }
            break;
	
          
	  
		


/*case pour affichage simplifi� car ajax */


		case 'getRoom': // APPEL DU FORMULAIRE DU PLANNING PAR SALLE
	
	

			$idSess=$_GET['idSess'];
			

			
			if ( isset($_SESSION[$idSess]) == false ) {
			
				$listRoom=rapladb::getResourcesNamesByType( array($conf['sitePref'][$uid]) );
				tools::setDefaults($idSess,$listRoom);
			
			}
		
			$s->assign("idform",$idSess);
			$s->assign("roomType",$_GET['roomType']);
			$s->assign("rooms",rapladb::getResourcesNamesByType( array($_GET['roomType']) ));

			$s->display('simple/getRoom.tpl');
		break;     
	

		case 'getGroup': // APPEL DU FORMULAIRE DU PLANNING PAR SALLE
	
	

			$idSess=$_GET['idSess'];
			

			
			if ( isset($_SESSION[$idSess]) == false ) {
				$listRoom=rapladb::getResourcesNamesByType( array($conf['sitePref'][$uid]) );
				tools::setDefaults($idSess,$listRoom);
			}
		
			$s->assign("idform",$idSess);
			$s->assign("groupKey",$_GET['groupKey']);
			$s->assign("groups",rapladb::getResourcesNamesByType( array($_GET['groupKey']) ));

			$s->display('simple/getGroup.tpl');
		break;     
        
		
		//Cas sans r�sultat
		case "ResVide" :
			
			$s->display('vide.tpl');
			break;
						
	    
    } //FIN DU SWITCH
    
    if(isset($pdf->pdf) == true)
    {
        header('Content-Type: application/pdf');
        $pdf->pdf->Output();
    }
    
    $db->disconnect();
?>
