<?php

//  D�marrage de la session.
session_start();



if( file_exists( '../local.configuration.php' ) ) 
{
    require_once( '../local.configuration.php');
   require_once('../php-includes/objets/utilisateur.php');
    $IP=$_SERVER["REMOTE_ADDR"]; 
    if (in_array($IP,$conf['ipClt']))
    {   
       
        $uid='rrapla';
       
        $user=new utilisateur($uid);
        $user->lecture=TRUE;
        $_SESSION['utilisateur']=$user;
        
        
    }
    else
    {
        if ( ! isset ($_SERVER['PHP_AUTH_USER'])) {
        header('WWW-Authenticate: Basic realm="My Realm"');
        header('HTTP/1.0 401 Unauthorized');
        echo 'Texte utilis� si le visiteur utilise le bouton d\'annulation';
        exit;
        }

        $uid= $_SERVER['PHP_AUTH_USER'];
        
       
        
        $user=new utilisateur($uid);
        $_SESSION['utilisateur']=$user;
    }
	
}
else 
{
  require_once( '../configuration.php');
   require_once('../php-includes/objets/utilisateur.php');
    $IP=$_SERVER["REMOTE_ADDR"]; 
    if (in_array($IP,$conf['ipClt']))
    {   
        $uid='crapla';
        $user=new utilisateur($uid);
        $user->lecture=TRUE;
        $_SESSION['utilisateur']=$user;
        
    }
    else
    {
        require_once('CAS.php');
        require_once('../php-includes/local/auth.php');

        $uid=auth::authenticate(); 

       

        $user=new utilisateur($uid);
        $_SESSION['utilisateur']=$user;
    }

}

if ($_SESSION['utilisateur']->lecture == false )
{
$message = "<h1>Désolé</h1> <p> Vous n'êtes pour l'instant pas autorisé à utiliser ce service. </p> ";
die($message);

}



require_once( 'DB.php' );
require_once( 'Smarty.class.php' );
require_once( $conf['appRoot'] . '/php-includes/include.php' );

// Connexion a la base de donn�es
$db = DB::connect( $database['raplaro'] );
if ( DB::isError( $db ) )
{
    $message = "<h1>D�sol�.</h1><p>Le site est inaccessible pour le moment.</p>
        <p>Nous nous excusons de la g�ne occasionn�e, le service sera r�tabli dans les plus brefs d�lais.</p>
        <hr />";

    $message .= $db->getMessage()."\n";
    die ( $message );
}

$db->setFetchMode( DB_FETCHMODE_ASSOC );
$db->query("SET NAMES 'utf8_general_ci'");
$db->query("SET CHARACTER SET utf8_general_ci");     








setlocale(LC_ALL, "fr_FR.UTF-8");
//  D�marrage de Smarty
$s = new Smarty;
$s->template_dir  = $conf['appRoot'].'/'.$smartyConf['template_dir'];
$s->compile_dir   = $conf['appRoot'].'/'.$smartyConf['compile_dir'];
$s->config_dir    = $conf['appRoot'].'/'.$smartyConf['config_dir'];
$s->cache_dir     = $conf['appRoot'].'/'.$smartyConf['cache_dir'];
$s->plugins_dir[] = $conf['appRoot'].'/'.$smartyConf['plugins_dir'];
$s->compile_check = $smartyConf['compile_check'];
$s->caching       = $smartyConf['caching'];
$s->cache_lifetime= $smartyConf['cache_lifetime'];
$s->use_sub_dirs  = $smartyConf['use_sub_dirs'];
$s->force_compile = $smartyConf['force_compile'];

$webRoot = $conf['webRoot'];




//pr�cise un site par d�fault (molitor pour les adresse de molitor sinon bat
if(!isset($conf['sitePref'][$uid])){

	$adrIp=explode(".",$_SERVER['REMOTE_ADDR']);
	if( ($adrIp[0]==192 && $adrIp[1]==168) || ($adrIp[0]==172 && 16<=$adrIp[1] && $adrIp[1]<=31)){
		if($adrIp[2]<128){
			$conf['sitePref'][$uid]=array(SALLES_MOL);

		}else{
			$conf['sitePref'][$uid]=array(SALLES_BAT);	
		}
	}
}

?>