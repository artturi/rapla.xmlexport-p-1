<?php
    /**
    *  @author		Mikael Kermorgant
    *  Derived work inspired by Romain d'Alverny's
    *
    **/
require_once('inc.php');

$action = checks::getAction();
$nextpage = '';





switch( $action )
{    
    case 'form1': // formulaire de Plannning par SALLE
        $_SESSION['form1'] = $_POST['form1'];       
	if ($_POST['action2'] == 'refresh')
        {
            $nextpage = "page=form1";
        }    	
        //~ elseif ($_POST['action2'] == 'send' &&  isset($_POST['form1']['rooms']))
        elseif ($_POST['action2'] == 'send' )
        {
	        // Quel type de sortie
            if ( $_POST['form1']['viewmode'] == pdf )
                $nextpage="format=pdf&page=";
            elseif ( $_POST['form1']['viewmode'] == html )
                $nextpage="page=";
            // Quel TRI
            if ($_POST['form1']['sortMethod'] == TRI_JOUR_SALLE )
                $nextpage .= "dayRoom";
            elseif ($_POST['form1']['sortMethod'] == TRI_SALLE_JOUR )
                $nextpage .= "roomDay";
	    else 
	         $nextpage = "page=form1";
        }else{
            $nextpage = "page=form1";
	}
    	break;	
    
    case 'form2': // formulaire de Plannning par GROUPE
        $_SESSION['form2'] = $_POST['form2'];     
        if ($_POST['action2'] == 'refresh')
        {
            $nextpage = "page=form2";
        }
        elseif ($_POST['action2'] == 'send' &&  isset($_POST['form2']['group'] )) 
        {
            if ( $_POST['form2']['viewmode'] == pdf )
                $nextpage="format=pdf&page=";
            elseif ( $_POST['form2']['viewmode'] == html )
                $nextpage="page=";
				
            if ($_POST['form2']['sortMethod'] == TRI_JOUR_GROUPE )
                $nextpage .= "dayGroup";
            elseif ($_POST['form2']['sortMethod'] == TRI_GROUPE_JOUR )
                $nextpage .= "groupDay";
			else 
				$nextpage = "page=ResVide";
        }else{
            $nextpage = "page=ResVide";
	}
        break;
        
     case 'form3': // formulaire de Plannning par GROUPE
        $_SESSION['form3'] = $_POST['form3'];     
        if ($_POST['action2'] == 'refresh')
        {
            $nextpage = "page=form3";
        }
        elseif ($_POST['action2'] == 'send' && isset($_POST['form3']['persons']) )
        {
		if ( $_POST['form3']['viewmode'] == pdf )
			$nextpage="format=pdf&page=";
		elseif ( $_POST['form3']['viewmode'] == html )
			$nextpage="page=";
	
		if ($_POST['form3']['sortMethod'] == TRI_JOUR_INTERVENANT )                  
			$nextpage .= "dayPerson"; 
               
		elseif ($_POST['form3']['sortMethod'] == TRI_INTERVENANT_JOUR )
			$nextpage .= "personDay";
		 else 
			$nextpage = "page=ResVide";
                
		
            
        }else{
          $nextpage = "page=ResVide";
        }
        break;	
           
    case 'unpdf' :
        $_SESSION['unpdf'] = $_POST;     
       
        $nextpage = "page=globalPdf";
        
        break;
        
    case 'afficherPdfTV' :
	
		
		 
		
		$tv=rapladb::getAfficheEcran($_POST["ecran"]);
		
		
       
		$i=0;
		$nom_fichier = "ecran";
		$_GET=null;
		$_GET["page"]="planJour";
		$_GET["hStart"]="09";
		$_GET["hEnd"]="19";
		$_GET["site"]=array(constant($tv['site']));

		foreach($tv['auto'] as $auto){

			$_GET["group"][$i]=constant($auto['nomfich']);
			$i++;
		}
    
		if($debug){
			$_GET["debug"]=true;
			print_r($_GET);
		}
        if($_POST["ecran"]=="atvtice")
        {

            $_GET["pattern"]="info";
        }
        
        $_SESSION['unpdf'] = $_GET;     
       
        $nextpage = "page=globalPdf";
        
		
        break;    
    
    
          
   //gestion des �crans
    case 'formTv' :
	if(in_array($uid,$conf ["managers"])==false) $nextpage= "index.php";
	else{
		$nextpage = "page=tv&ecran=".$_POST["ecran"];
		if ($_POST['action2'] == 'Enlever'){
		
			if (isset($_POST['tvInfoAuto'])){ 
		
				foreach ($_POST['tvInfoAuto'] as $affSup) {
					rapladb::delAfficheLien($affSup,$_POST["ecran"]);
				}
			}
			if (isset($_POST['tvInfoManu'])){ 
				foreach ($_POST['tvInfoManu'] as $affSup) {
					
					rapladb::delAfficheLien($affSup,$_POST["ecran"]);
				}
			}
		
		}elseif($_POST['action2'] == 'Ajouter'){
			if (isset($_POST['auto'])){ 
			
				foreach ($_POST['auto'] as $fichADD) {
					
					rapladb::InsAfficheLien($fichADD,$_POST["ecran"]);
				}
			}
			if (isset($_POST['manu'])){ 
				foreach ($_POST['manu'] as $fichADD) {
					rapladb::InsAfficheLien($fichADD,$_POST["ecran"]);
				}
			}
		
		
		}elseif($_POST['action2'] == 'Supprimer'){
			if (isset($_POST['manu'])){ 
				foreach ($_POST['manu'] as $fichADD) {
					$fichier=rapladb::delLien($fichADD);
					if($fichier){
						$res=unlink($conf["upFile"].$fichier['nomfich']);
						if($res || !file_exists($conf["upFile"].$fichier['nomfich'])) $db->query('commit');
						else {
						
							$db->query('rollback');
						}
					}
					
				}
			}
			$db->autocommit(TRUE);
		}elseif($_POST['action2'] == 'affiche1pdf'){
			$idPdf=$_POST["pdf"];
			
			$tv=rapladb::getAfficheEcranFich($_POST["ecran"],$idPdf);
			
			if($tv["type"]=="auto"){
                if($_POST["ecran"]=="atvtice")
                {
                    $pattern="info";
                }
                else
                {
                    $pattern="";
                }
               
				$nextpage=$conf["webRoot"]."/index.php?page=globalPdf&hStart=09&hEnd=18&group[0]=".constant($tv['nomfich'])."&site[0]=".constant($tv['site'])."&pattern=".$pattern;
			}else{
				
				$nextpage=$conf["webRoot"]."/files/".$tv['nomfich'];
			}

			header( "Location: {$nextpage}");
			die();
		}	
		
		modifScript($_POST["ecran"]);
	}
	
	break;   



    
    case 'addFichier':
    
    
	if(in_array($uid,$conf ["managers"])==false) $nextpage= "index.php";
	else{
		$nextpage = "page=tv";
		

		
		if(!empty($_FILES['fichier']['tmp_name']) && is_uploaded_file($_FILES['fichier']['tmp_name'])){
			$nomFich=basename($_FILES['fichier']['name']);
			if($_FILES['fichier']['size']<3000000 && substr($nomFich,-4,4)==".pdf")
			{
				
				$uploadfile=$conf["upFile"] . $nomFich ;
				
				
				
				if(move_uploaded_file($_FILES['fichier']['tmp_name'],$uploadfile)){
					if(!rapladb::addFich($nomFich)){ //erreur d'importation dans la base donc suppr. du fichier
						unlink($uploadfile);
					}
				}
			}
		
		}
	
	}
	
	break;

    
    
    
    case 'default':
        $nextpage = "page=index";
        break;
}


/*fonction modifScript
@params : nomEcran (texte) : nom de l'�cran  qui permet r�cup�rer son adresse ip et autres informations (comme le site o� il se trouve)

Fonction qui cr�er le script shell qui sera utilis� par le mini-pc pour afficher les informations, ce fichier shell aurra comme nom l'adresse ip du mini-pc

renvoie : rien
*/
function modifScript($nomEcran){
	global $conf;

	$ecran=rapladb::getAfficheEcran($nomEcran);
	$fp=fopen($conf["scriptFile"].$ecran['ip'].".sh","w") or die("erreure ouverture fichier");

	fputs($fp,str_replace("\r\n","\n",file_get_contents($conf["appRoot"]."/www/script/avtWget.sh")));
	
	fputs($fp,"wget -O/root/my-documents/bienvenue.pdf '".$conf["webRoot"]."/files/bienvenue.pdf' \n");
	$i=0;
	$groupCode="";
	if(isset($ecran['auto']) ){
		foreach ($ecran['auto'] as $auto ){
			//~ fputs($fp,"  wget -O/root/my-documents/tmp/".$auto['lib'].".pdf '".$conf["webRoot"]."/index.php?page=globalPdf&group[0]=".constant($auto['nomfich'])."&site[0]=".constant($ecran['site'])."&hStart='\$heure'&hEnd='\$end\n");
			$groupCode.="&group[$i]=".constant($auto['nomfich']);
			$i++;
		}
	}
	if($i>0)
		fputs($fp,"  wget -O/root/my-documents/tmp/auto.pdf '".$conf["webRoot"]."/index.php?page=globalPdf".$groupCode."&site[0]=".constant($ecran['site'])."&hStart='\$heure'&hEnd='\$end\n");
	
	if(isset($ecran['manu'] )){
		foreach ($ecran['manu'] as $manu ){
			fputs($fp,"  wget -O/root/my-documents/tmp/".$manu['nomfich']." '".$conf["webRoot"]."/files/".$manu['nomfich']."'\n");
		}
	}
	fputs($fp,str_replace("\r\n","\n",file_get_contents($conf["appRoot"]."/www/script/apresWget.sh")));
	
	fclose($fp);
	
	

}





//  Redirection
$path = $webRoot.'/?'.$nextpage;
// print_r($_POST);
// echo $path;

header( "Location: {$path}");
exit();
?>
