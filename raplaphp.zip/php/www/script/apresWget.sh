while [ "$heure" == $( date '+%H' ) ] && [ "$dif" -lt "5" ]
do


	for((j=1;j<15;j++))
	do
		#parcours des fichiers pdf
		for fichier in /root/my-documents/tmp/*.pdf 
		do
			#recupération du nombre de page dans le pdf
			nbPage=$(pdfinfo $fichier |grep 'Pages:' | cut -d: -f2 | tr -d [:space:])
			for((i=1;i<$nbPage+1;i++))
			do
				xpdf -remote $remoteName $fichier $i -fullscreen -papercolor black &
				sleep 8
			done
		done
	done
	xpdf -remote $remoteName /root/my-documents/bienvenue.pdf 1 -fullscreen -papercolor black &
	sleep 4

	newM=$( date '+%M' )
	dif=$(($newM   - $min))

done
