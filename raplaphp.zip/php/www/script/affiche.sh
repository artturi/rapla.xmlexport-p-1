#!/bin/bash

#attribution d'un nom pour xpdf ne ce lance pas plusieur fois
remoteName="principal"

rm -f /root/my-documents/*.pdf
while [ 1=1 ]
do
{

	
		wget -O/root/my-documents/pe2.pdf 'http://planning.opaque.paris.iufm.fr/print/treatpdf.php?page=planJour&group[0]=resource7&site=resource1&hStart=08:00:00&hEnd=23:00:00'
		wget -O/root/my-documents/plc1.pdf 'http://planning.opaque.paris.iufm.fr/print/treatpdf.php?page=planJour&group[0]=resource9&site=resource1&hStart=08:00:00&hEnd=23:00:00'


	for((j=1;j<15;j++))
	do
	{
		#parcours des fichiers pdf	
		for fichier in /root/my-documents/*.pdf
		do
		{    
		    #recupération du nombre de page dans le pdf
		    nbPage=$(pdfinfo $fichier |grep "Pages:" | cut -d: -f2 | tr -d [:space:])
		    #echo "nb page =$nbPage"
		    for((i=1;i<=$nbPage;i++))
		    do
		    {
				#export DISPLAY=:1.0
				xpdf -remote $remoteName $fichier $i -fullscreen -papercolor black &
			
				#echo "voici le process $!"
			
				sleep 7
			#kill -15 $!
		    }
		    done
		}
		done
	}
	done
}
done 