#!/bin/bash\n #attribution d'un nom pour xpdf ne ce lance pas plusieur fois
remoteName='principal'
rm -f /root/my-documents/tmp/*.pdf
heure=$( date '+%H') 
min=$( date '+%M' )
newM=$( date '+%M' )
dif=$(($newM   - $min))

if [ "$heure" -lt "12" ]
then
   end=13
else
   end=20
fi
