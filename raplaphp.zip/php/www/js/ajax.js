





 	 
function showRoom(idForm,idRoomType){
	var req = null; 
	
	if(document.getElementById(idRoomType).style.visibility == 'hidden'){
		document.getElementById(idRoomType).style.visibility='visible';
		document.getElementById(idRoomType).innerHTML="Demande...";
		if(window.XMLHttpRequest)
			req = new XMLHttpRequest(); 
		else if (window.ActiveXObject)
			
			req= new ActiveXObject("Microsoft.XMLHTTP");
			//req  = new ActiveXObject(Microsoft.XMLHTTP); 

		req.onreadystatechange = function()
		{ 
			document.getElementById(idRoomType).innerHTML="Chargement...";
			if(req.readyState == 4)
			{
				if(req.status == 200)
				{
					document.getElementById(idRoomType).innerHTML= req.responseText;	
				}	
				else	
				{
					document.getElementById(idRoomType).innerHTML="Error: returned status code " + req.status + " " + req.statusText;
				}	
			} 
		}; 
		req.open("GET","index.php?page=getRoom&idSess="+idForm+"&roomType="+idRoomType, true); 
		req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"); 
		req.send(""); 

	}else{	

		document.getElementById(idRoomType).style.visibility='hidden';
		
		document.getElementById(idRoomType).innerHTML="";
		
	}

}


function showGroup(idForm,idGroup){
	var req = null; 
	
	if(document.getElementById(idGroup).style.visibility == 'hidden'){
		document.getElementById(idGroup).style.visibility='visible';
		document.getElementById(idGroup).innerHTML="Demande...";
		if(window.XMLHttpRequest)
			req = new XMLHttpRequest(); 
		else if (window.ActiveXObject)
			
			req= new ActiveXObject("Microsoft.XMLHTTP");
			//req  = new ActiveXObject(Microsoft.XMLHTTP); 

		req.onreadystatechange = function()
		{ 
			document.getElementById(idGroup).innerHTML="Chargement...";
			if(req.readyState == 4)
			{
				if(req.status == 200)
				{
					document.getElementById(idGroup).innerHTML= req.responseText;	
				}	
				else	
				{
					document.getElementById(idGroup).innerHTML="Error: returned status code " + req.status + " " + req.statusText;
				}	
			} 
		}; 
		req.open("GET","index.php?page=getGroup&idSess="+idForm+"&groupKey="+idGroup, true); 
		req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"); 
		req.send(""); 

	}else{	

		document.getElementById(idGroup).style.visibility='hidden';
		
		document.getElementById(idGroup).innerHTML="";
		
	}

}




function showdiv(idDiv,check){
	allDiv="all_"+idDiv;

	if(document.getElementById(check).checked){
		document.getElementById(allDiv).style.visibility='visible';
		
	}else{	
		document.getElementById(allDiv).style.visibility='hidden';
		
		document.getElementById(idDiv).innerHTML="";
	}
}

