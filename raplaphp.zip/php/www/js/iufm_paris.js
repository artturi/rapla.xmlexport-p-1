function refresh(form) {
  document.getElementById(form).action2.value = 'refresh';
  document.getElementById(form).submit();
}

function showhideDivChgImg(id,imgId){
	img = document.getElementById(imgId);
	
	var reg1=new RegExp("triHor.gif","g");
	if(	img.src.match(reg1) ){
		img.src="img/triVert.gif";
	}else{
		img.src="img/triHor.gif" ;
	}
	showhideDiv(id);
}
function showhideDiv(id)
{
  obj = document.getElementById(id);
  if(obj.style.display == 'none'){
	obj.style.display =  'block';
  }else{
	obj.style.display =  'none';
  }
}

function showhide(id, cb)
{
  obj = document.getElementById(id);
  obj.style.display = (cb.checked)? 'block': 'none';
}
function selectAll(id, flagname)
{
  window[flagname] = (window[flagname] == true)? false : true;
  select = document.getElementById(id);
  for (var i=select.options.length-1 ;i>=0;i--) {  select.options[i].selected = window[flagname];   }
}

function checkAll(id, flagname)
{
  window[flagname] = (window[flagname] == true)? false : true;
  check = document.getElementById(id);
  for (var i=select.options.length-1 ;i>=0;i--) {  select.options[i].selected = window[flagname];   }
}


